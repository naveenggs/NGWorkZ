//
//  NSString+FormValidation.m
//  CheckApp
//
//  Created by Tushar on 04/08/16.
//  Copyright © 2016 CheckApp Healthcare Pvt Ltd. All rights reserved.
//

#import "NSString+FormValidation.h"

@implementation NSString (FormValidation)

- (BOOL)isValidEmail {
//    NSString *regex = @"[^@]+@[A-Za-z0-9.-]+\\.[A-Za-z]+";
//    NSPredicate *emailPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
//    return [emailPredicate evaluateWithObject:self];
    
    const char cRegex[] = "^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$";
    NSString *emailRegex = [NSString stringWithUTF8String:cRegex];
    NSPredicate *emailPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES[c] %@", emailRegex];
    BOOL isValid = [emailPredicate evaluateWithObject:self];
    return isValid;
//    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
//    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
//    
//    return [emailTest evaluateWithObject:self];
}

- (BOOL)isValidName {
    NSString *regex = @"^[A-Za-z]+(\\s[A-Za-z]+)*$";
    NSPredicate *textPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [textPredicate evaluateWithObject:self];
}

- (BOOL)isValidNumber {
    /*NSString *regex = @"^[0-9]+(\\.[0-9]+)*$";
    NSPredicate *numberPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [numberPredicate evaluateWithObject:self];*/
    return (self.length == 10);
}

- (BOOL)isValidPin
{
    /*NSString *regex = @"^[0-9]+(\\.[0-9]+)*$";
     NSPredicate *numberPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
     return [numberPredicate evaluateWithObject:self];*/
    return (self.length == 6);
}

- (BOOL)isValidPassword {
    /*NSString *regex = @"^[0-9]+(\\.[0-9]+)*$";
     NSPredicate *numberPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
     return [numberPredicate evaluateWithObject:self];*/
    return (self.length >= 6 && self.length <= 14);//6 to 14
}

- (BOOL)isEmpty {
    if (self.length < 1) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)containsOnlySpaces {
    NSString *regex = @"^ *$";
    NSPredicate *spacePredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [spacePredicate evaluateWithObject:self];
}

-(BOOL)isNumeric{
    BOOL isValid = NO;
    NSCharacterSet *alphaNumbersSet = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *stringSet = [NSCharacterSet characterSetWithCharactersInString:self];
    isValid = [alphaNumbersSet isSupersetOfSet:stringSet];
    return isValid;
}

-(NSString *)stringWithNonDigitsRemoved
{
    NSString *newString = [[self componentsSeparatedByCharactersInSet:
                            [[NSCharacterSet letterCharacterSet] invertedSet]] componentsJoinedByString:@""];
    return newString;
}



@end
