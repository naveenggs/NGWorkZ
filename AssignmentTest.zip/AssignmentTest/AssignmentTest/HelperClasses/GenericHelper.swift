//
//  GenericHelper.swift
//  ClientApp
//
//  Created by Naveen Gundu on 21/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import UIKit

enum ErrorCode : String {
    case sessionExpired = "TOKENERROR"
    case forceUpdate = "FORCEUPDATE"
    case rechability = "NOINTERNET"
}
enum JsonResult : String{
    
    case success = "SUCCESS"
    case failure = "FAILURE"
}
enum Screen : Int {
    case Doctor = 0
    case Lab = 1
    case Pharmacy = 2
}

//func debugPrint(_ items: Any..., separator: String = " ", terminator: String = "\n") {
//    #if DEBUG
//       Swift.debugPrint(items[0], separator:separator, terminator: terminator)
//    #endif
//}
//
//func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
//    #if DEBUG
//       Swift.print(items[0], separator:separator, terminator: terminator)
//    #endif
//}

class GenericHelper {
    
    
    func applyTopBottomLine(_ obj:AnyObject) {
        
        if let textField = obj as? UITextField{
            
            let lblT = UILabel.init(frame: CGRect(x: 0, y: 1, width: textField.frame.size.width, height: 1))
            lblT.backgroundColor = UIColor.lightGray
            
            let lbl = UILabel.init(frame: CGRect(x: 0, y: textField.frame.size.height - 2, width: textField.frame.size.width, height: 1))
            lbl.backgroundColor = UIColor.lightGray
            textField.addSubview(lbl)
            textField.addSubview(lblT)
            
        }
        if let uC = obj as? UIControl{
            
            let lblT = UILabel.init(frame: CGRect(x: 0, y: 1, width: uC.frame.size.width, height: 1))
            lblT.backgroundColor = UIColor.lightGray
            
            let lbl = UILabel.init(frame: CGRect(x: 0, y: uC.frame.size.height - 2, width: uC.frame.size.width, height: 1))
            lbl.backgroundColor = UIColor.lightGray
            uC.addSubview(lbl)
            uC.addSubview(lblT)
        }
        
        if let btn = obj as? UIButton {
            let lbl = UILabel.init(frame: CGRect(x: 0, y: btn.frame.size.height - 2, width: btn.frame.size.width, height: 1))
            lbl.backgroundColor = .lightGray
            btn.addSubview(lbl)
        }
        if let lblN = obj as? UILabel {
            let lbl = UILabel.init(frame: CGRect(x: 0, y: lblN.frame.size.height - 2, width: lblN.frame.size.width, height: 1))
            lbl.backgroundColor = .lightGray
            lblN.addSubview(lbl)
        }
        
    }
    func buttonTouchEffect(_ sender:UIButton, _ color:UIColor) {
        let colorAnimation = CABasicAnimation(keyPath: "backgroundColor")
        colorAnimation.fromValue = color.cgColor
        colorAnimation.duration = 1  // animation duration
        // colorAnimation.autoreverses = true // optional in my case
        // colorAnimation.repeatCount = FLT_MAX // optional in my case
        sender.layer.add(colorAnimation, forKey: "ColorPulse")
    }
    func rightViewTF(_ TF:UITextField, _ image:String) {
        
        TF.leftViewMode = UITextField.ViewMode.always
        TF.leftViewMode = .always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 6, width: 18, height: 18))
        let image = UIImage(named: image)
        imageView.image = image
        TF.leftView = imageView
    }
    func applyBottomLine(_ obj:AnyObject) {
        
        if let textField = obj as? UITextField{
            let lbl = UILabel.init(frame: CGRect(x: 0, y: textField.frame.size.height - 2, width: textField.frame.size.width, height: 1))
            lbl.backgroundColor = UIColor.lightGray
            textField.addSubview(lbl)
        }
        if let uC = obj as? UIControl{
            
            //            let lblT = UILabel.init(frame: CGRect(x: 0, y: 1, width: uC.frame.size.width, height: 1))
            //            lblT.backgroundColor = UIColor.init(hexString: Constants().LineColor)
            
            let lbl = UILabel.init(frame: CGRect(x: 0, y: uC.frame.size.height - 2, width: uC.frame.size.width, height: 1))
            lbl.backgroundColor = UIColor.lightGray
            uC.addSubview(lbl)
            //            uC.addSubview(lblT)
        }
        if let btn = obj as? UIButton {
            let lbl = UILabel.init(frame: CGRect(x: 0, y: btn.frame.size.height - 2, width: btn.frame.size.width, height: 1))
            lbl.backgroundColor = UIColor.lightGray
            btn.addSubview(lbl)
        }
        if let lblN = obj as? UILabel {
            let lbl = UILabel.init(frame: CGRect(x: 0, y: lblN.frame.size.height - 2, width: lblN.frame.size.width, height: 1))
            lbl.backgroundColor = UIColor.lightGray
            lblN.addSubview(lbl)
        }
    }
    
    func applyTFPopUp(_ tf:UITextField) {
        
        tf.borderStyle = .none
        tf.returnKeyType = .done
        tf.layer.cornerRadius = 14.0
        tf.layer.masksToBounds = true
        tf.clipsToBounds = true
        tf.layer.borderColor = UIColor.lightGray.cgColor
        tf.layer.borderWidth = 1.0
        tf.resignFirstResponder()
        
    }
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    func downloadImage(url: URL, imageView:UIImageView) {
        print("Download Started")
        let actityVity = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)
        actityVity.center = imageView.center
        actityVity.hidesWhenStopped = false
        actityVity.startAnimating()
        imageView.addSubview(actityVity)
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() {
                imageView.image = UIImage(data: data)
                actityVity.stopAnimating()
                actityVity.removeFromSuperview()
            }
        }
    }
    func changeButtonColor(index:Int, button:UIButton) {
        
        if index == 0 {
            
            button.backgroundColor = UIColor.white
            button.setTitleColor(Constants().blueyPurple, for: .normal)
            button.layer.borderColor = Constants().blueyPurple.cgColor
            
        }
        else{
            button.backgroundColor = Constants().blueyPurple
            button.setTitleColor(UIColor.white, for: .normal)
            button.layer.borderColor = UIColor.white.cgColor
            
        }
        
        button.layer.cornerRadius = button.frame.size.height / 2
        button.layer.borderWidth = 1.0
    
    }
    func applyCornerRadius(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.cornerRadius = 4.0
    }
    func applyLayerShadowBlack(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.shadowColor = UIColor.lightGray.cgColor
        object.layer.shadowOffset = CGSize.init(width: 0.0, height: 2.0)
        object.layer.shadowOpacity = 0.8
        object.layer.shadowRadius = 2.0
    }
    func applyLayerShadowLightBlack(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.shadowColor = UIColor.lightGray.cgColor
        object.layer.shadowOffset = CGSize.init(width: 0.0, height: 1.0)
        object.layer.shadowOpacity = 0.8
        object.layer.shadowRadius = 1.0
    }
    
    func applyLayerShadow(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.shadowColor = UIColor.init(fromHexString: Constants().bluey_grey, 1).cgColor
        object.layer.shadowOffset = CGSize.init(width: 0, height: 2)
        object.layer.shadowRadius = 0.3
        object.layer.shadowOpacity = 0.1
    }
    func applyLayerShadowDeep(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.shadowColor = UIColor.init(fromHexString: Constants().bluey_grey, 1).cgColor
        object.layer.shadowOffset = CGSize.init(width: 0, height: 5)
        object.layer.shadowRadius = 0.5
        object.layer.shadowOpacity = 0.5
    }
    func applyLayerShadowFull(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.shadowColor = UIColor.init(fromHexString: Constants().bluey_grey, 1).cgColor
        object.layer.shadowOffset = CGSize.init(width: 0, height: 0)
        object.layer.shadowOpacity = 5.0
        object.layer.shadowRadius = 2.0
    }
    func applyLayerShadowDeepLength(_ object : AnyObject)
    {
        object.layer.masksToBounds = false;
        object.layer.shadowColor = UIColor.init(fromHexString: Constants().bluey_grey, 1).cgColor
        object.layer.shadowOffset = CGSize.init(width: 0, height: 4)
        object.layer.shadowOpacity = 0.5
        object.layer.shadowRadius = 5.0
    }
//
//    func showToast(message : String, viewcontroller :UIViewController) {
//         DispatchQueue.main.async {
//        let toastLabel = UILabel(frame: CGRect(x: viewcontroller.view.center.x, y: viewcontroller.view.center.y/2, width: 200, height: 50))
//
//        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
//        toastLabel.textColor = UIColor.white
//        toastLabel.textAlignment = .center;
//        toastLabel.font = UIFont(name: Constants().SFProTextBold, size: Constants().fontSize12)
//        toastLabel.text = message
//        toastLabel.sizeToFit()
//
//        toastLabel.alpha = 1.0
//        toastLabel.layer.cornerRadius = 10;
//        toastLabel.clipsToBounds  =  true
//        toastLabel.center = viewcontroller.view.center
//        viewcontroller.view.addSubview(toastLabel)
//        UIView.animate(withDuration: 3.0, delay: 0.5, options: .curveEaseOut, animations: {
//            print("Status...?")
//            toastLabel.alpha = 0.0
//            viewcontroller.view.isUserInteractionEnabled = false
//
//
//        }, completion: {(isCompleted) in
//            print("Find...?")
//            viewcontroller.view.isUserInteractionEnabled = true
//
//
//
//            toastLabel.removeFromSuperview()
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            let initialViewController = storyboard.instantiateViewController(withIdentifier: "LogInViewController")
//            var controllersArray = viewcontroller.navigationController?.viewControllers
//            controllersArray?.insert(initialViewController, at: 0)
//            viewcontroller.navigationController?.setViewControllers(controllersArray!, animated: false)
//            GenericHelper().customPopToRootViewController(viewcontroller, animation: true)
//        })
//        }
//    }
//
//    func mbprogressShowToast(text : String,point : CGPoint){
//        DispatchQueue.main.async {
//        let hud = MBProgressHUD.showAdded(to: (UIApplication.topViewController()?.view)!, animated: true)
//        hud.show(animated: true)
//        //showHUDAddedTo:self.view animated:YES];
//
//        // Set the text mode to show only text.
//        hud.mode = .text
//        hud.label.text = text
//        hud.label.numberOfLines = 0;
//        // Move to bottm center.
//        hud.offset = point
//        hud.hide(animated: true, afterDelay: 3.0)
//        }
//    }
//
    func hudShow(view : UIView , string : String){
        DispatchQueue.main.async {
        if (view.viewWithTag(707) != nil){
            GenericHelper().dismissShow(view: view)
        }
        let hud = MBProgressHUD.showAdded(to: view, animated: true)
        hud.tag = 707
        hud.mode = MBProgressHUDMode.indeterminate
        hud.bezelView.color = UIColor.init(white: 1, alpha: 1)
        hud.backgroundView.color = UIColor.init(white: 0, alpha: 0.3)
        if string != "" {
            hud.label.text = string
        }
        }
    }

    func dismissShow(view : UIView){
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: view, animated: true)
        }
    }
//
//    func addFloatingTextfield(textfield : SkyFloatingLabelTextField) -> SkyFloatingLabelTextField {
//        textfield.tintColor = UIColor.init(fromHexString: Constants().primaryColorString, 1)  // the color of the blinking cursor
//        textfield.textColor = UIColor.black
//        textfield.selectedTitleColor = UIColor.init(fromHexString: Constants().secondaryColorString, 1)
//        textfield.selectedLineColor = UIColor.init(fromHexString: Constants().primaryColorString, 1)
//        return textfield
//    }
//
//    func bottomBorderTextfield(textfield : UITextField, color: UIColor) -> UITextField {
//        let border = CALayer()
//        let width = CGFloat(2.0)
//        border.borderColor = color.cgColor
//        border.frame = CGRect(x: 0, y: textfield.frame.size.height - width, width:  textfield.frame.size.width, height: width)
//
//        border.borderWidth = width
//        textfield.layer.addSublayer(border)
//        textfield.layer.masksToBounds = true
//        return textfield
//    }
//
//    func bottomBorderButton(button : UIButton, color: UIColor) -> UIButton {
//        let border = CALayer()
//        let width = CGFloat(1.0)
//        border.borderColor = color.cgColor
//        border.frame = CGRect(x: 0, y: button.frame.size.height - width, width:  button.frame.size.width, height: width)
//
//        border.borderWidth = width
//        button.layer.addSublayer(border)
//        button.layer.masksToBounds = true
//        return button
//    }
//
//    func heightForView(text:String, font:UIFont, width:CGFloat, label: Bool, textView : Bool) -> CGFloat{
//        if(label){
//            let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
//            label.numberOfLines = 0
//            label.lineBreakMode = NSLineBreakMode.byTruncatingTail
//            label.font = font
//            label.text = text
//            label.sizeToFit()
//            let fixedWidth = width
//            label.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
//            let newSize = label.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
//            var newFrame = label.frame
//            newFrame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)
//            label.frame = newFrame;
//            return label.frame.height
//        }else{
//
//            let textView:UITextView = UITextView(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
//
//            //textView.numberOfLines = 0
//
//            //textView.lineBreakMode = NSLineBreakMode.byTruncatingTail
//
//            //textView.font = font
//
//            textView.text = text
//
//            textView.sizeToFit()
//
//
//
//            return textView.frame.height
//
//        }
//
//
//    }
//
//    func heightForViewWithAttributedString(tv : UITextView,text: NSMutableAttributedString, width:CGFloat) -> CGFloat{
//        let fixedWidth = tv.frame.size.width
//        tv.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
//        let newSize = tv.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
//        var newFrame = tv.frame
//        newFrame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)
//        tv.frame = newFrame;
//        return tv.frame.height
//    }
//
//    func widthForView(text:String, font:UIFont, label: Bool) -> CGFloat{
//        if(label){
//            let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
//            label.numberOfLines = 1
//            label.lineBreakMode = NSLineBreakMode.byTruncatingTail
//            label.font = font
//            label.text = text
//            label.sizeToFit()
//
//            return label.frame.width
//        }else{
//            return 0
//        }
//    }
//
//    func titleAttributeString(text : String, bullet : Bool) -> NSAttributedString{
//
//        var attributedTitleString = NSMutableAttributedString()
//
//        let attributes : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.black]
//        let attributesBullet : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.init(hexString: Constants().slate_grey_two)]
//
//        if(bullet){
//
//            let bulletPoint = NSAttributedString.init(string: "\u{2022} ", attributes: attributesBullet)
//
//            let formattedString: String = " \(text)\n"
//
//            let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//            attributedString.insert(bulletPoint, at: 0)
//            let paragraphStyle = createParagraphAttribute()
//
//            attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//            attributedTitleString.append(attributedString)
//
//
//
//        }else{
//
//            attributedTitleString = NSMutableAttributedString(string: "\(text)", attributes: attributes)
//
//        }
//
//        return attributedTitleString
//
//    }
//
//    func titleAttributeStringRange(text : String, bullet : Bool) -> NSAttributedString{
//
//        var attributedTitleString = NSMutableAttributedString()
//
//        let attributes : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.black]
//        let attributesRegular : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.black]
//        if(bullet){
//
//            let bulletPoint: String = "\u{2022} "
//
//            let formattedString: String = "\(bulletPoint) \(text)\n"
//
//            let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//
//            let paragraphStyle = createParagraphAttribute()
//
//            attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//            attributedTitleString.append(attributedString)
//
//
//
//        }else{
//
//            attributedTitleString = NSMutableAttributedString(string: "\(text)", attributes: attributesRegular)
//           // attributedTitleString.addAttributes(attributes, range: NSRange.init(location: rangeStart, length: rangeEnd))
//           // attributedTitleString.addAttributes(attributesRegular, range: NSRange.init(location: rangeEnd, length: attributedTitleString.length))
//        }
//
//        return attributedTitleString
//
//    }
//
//    func titleAttributeStringWithArrow(text : String, arrow : Bool) -> NSMutableAttributedString{
//
//        var attributedTitleString = NSMutableAttributedString()
//
//        let attributes : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.init(fromHexString: Constants().slate_grey, 1)]
//
//        if(arrow){
//
//            let bulletPoint: String = "\u{25B8} "
//
//            let formattedString: String = "\(bulletPoint) \(text)\n"
//
//            let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//
//            let paragraphStyle = createParagraphAttribute()
//
//            attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//            attributedTitleString.append(attributedString)
//
//
//
//        }else{
//
//            attributedTitleString = NSMutableAttributedString(string: "\(text)", attributes: attributes)
//
//        }
//
//        return attributedTitleString
//
//    }
//
//
//    func subtitleAttributeString(texts : String, bullet : Bool) -> NSMutableAttributedString{
//
//        var attributedTitleString = NSMutableAttributedString()
//
//        var textArr = texts.characters.split{$0 == "\n"}.map(String.init)
//
//        for text in textArr{
//
//            let attributes : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.black]
//
//            if(bullet){
//
//                let bulletPoint: String = "\u{25B6} "
//
//                let formattedString: String = "\(bulletPoint) \(text)\n"
//
//                let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//
//                let paragraphStyle = createParagraphAttribute()
//
//                attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//                attributedTitleString.append(attributedString)
//
//
//
//            }else{
//
//                let bulletPoint: String = "   "
//
//                let formattedString: String = "\(bulletPoint) \(text)\n"
//
//                let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//
//                let paragraphStyle = createParagraphAttribute()
//
//                attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//                attributedTitleString.append(attributedString)
//
//            }
//
//        }
//
//        return attributedTitleString
//
//    }
//
//    func subtitleAttributeStringWithArrow(texts : String, arrow : Bool) -> NSMutableAttributedString{
//
//        var attributedTitleString = NSMutableAttributedString()
//
//        var textArr = texts.characters.split{$0 == "\n"}.map(String.init)
//
//        for text in textArr{
//
//            let attributes : [String : Any] = [NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, NSForegroundColorAttributeName : UIColor.black]
//
//            if(arrow){
//
//                let bulletPoint: String = "  \u{25B8} "
//
//                let formattedString: String = "\(bulletPoint) \(text)\n"
//
//                let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//
//                let paragraphStyle = createParagraphAttribute()
//
//                attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//                attributedTitleString.append(attributedString)
//
//
//
//            }else{
//
//                let bulletPoint: String = "   "
//
//                let formattedString: String = "\(bulletPoint) \(text)\n"
//
//                let attributedString: NSMutableAttributedString = NSMutableAttributedString(string: formattedString , attributes: attributes)
//
//                let paragraphStyle = createParagraphAttribute()
//
//                attributedString.addAttributes([NSParagraphStyleAttributeName: paragraphStyle], range: NSMakeRange(0, attributedString.length))
//
//                attributedTitleString.append(attributedString)
//
//            }
//
//        }
//
//        return attributedTitleString
//
//    }
//
//
//    func createParagraphAttribute() ->NSParagraphStyle
//
//    {
//
//        var paragraphStyle: NSMutableParagraphStyle
//
//        paragraphStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
//
//        paragraphStyle.tabStops = [NSTextTab(textAlignment: .left, location: 15, options: NSDictionary() as! [String : AnyObject])]
//
//        paragraphStyle.defaultTabInterval = 15
//
//        paragraphStyle.firstLineHeadIndent = 0
//
//        paragraphStyle.headIndent = 15
//
//
//
//        return paragraphStyle
//
//    }
//
//
//
//    func createParagraphSubtitleAttribute() ->NSParagraphStyle
//
//    {
//
//        var paragraphStyle: NSMutableParagraphStyle
//
//        paragraphStyle = NSParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
//
//        paragraphStyle.tabStops = [NSTextTab(textAlignment: .left, location: 15, options: NSDictionary() as! [String : AnyObject])]
//
//        paragraphStyle.defaultTabInterval = 15
//
//        paragraphStyle.firstLineHeadIndent = 0
//
//        paragraphStyle.headIndent = 15
//
//        return paragraphStyle
//
//    }
//
//    func respRedirect(errorString : String, dynamicVC : UIViewController, errorCodeString  : String, completionHandler:  ((_ button : UIButton?) -> ())?){
//        DispatchQueue.main.async {
//            GenericHelper().dismissShow(view: dynamicVC.view)
//            dynamicVC.tabBarController?.tabBar.isHidden = true
//            if errorCodeString == "TOKENERROR"{
//                let ToastAlert = UIAlertController(title: nil, message: errorString, preferredStyle: UIAlertControllerStyle.alert)
//                let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (result : UIAlertAction) -> Void in
//
//                    UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
//                    UserDefaults.standard.synchronize()
//                    if(dynamicVC.isKind(of: PatientINBOXViewController.self) || dynamicVC.isKind(of: SearchTabViewController.self)){
//                        dynamicVC.tabBarController?.tabBar.isHidden = false
//                    }
//                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                    let initialViewController = storyboard.instantiateViewController(withIdentifier: "LogInViewController")
//                    var controllersArray = dynamicVC.navigationController?.viewControllers
//                    controllersArray?.insert(initialViewController, at: 0)
//                    dynamicVC.navigationController?.setViewControllers(controllersArray!, animated: false)
//                    GenericHelper().customPopToRootViewController(dynamicVC, animation: true)
//
//                }
//                ToastAlert.addAction(okAction)
//
//                dynamicVC.present(ToastAlert, animated: true, completion: nil)
//
//            }else if errorCodeString == "FORCEUPDATE"{
//                let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                let controller = storyboard.instantiateViewController(withIdentifier: "ForceUpdateViewController") as! ForceUpdateViewController
//                GenericHelper().customPush(dynamicVC, viewControler: controller, animation: true)
//            }else if errorCodeString == "NOINTERNET"{
//                for view in dynamicVC.view.subviews{
//                    if view.tag == 404{
//                        view.removeFromSuperview()
//                    }
//                }
//                dynamicVC.tabBarController?.tabBar.isHidden = true
//                let backView = UIView(frame: CGRect(x: 0, y: 0, width: dynamicVC.view.frame.size.width, height: dynamicVC.view.frame.size.height))
//                backView.backgroundColor = UIColor.white
//                backView.center = dynamicVC.view.center
//                backView.tag = 404
//
//                let imageViewObject : UIImageView
//                imageViewObject = UIImageView(frame: CGRect(x: 56,y: 0,width: backView.bounds.width - 112 ,height: 184))
//                imageViewObject.image = UIImage(named: "NoInternet")
//                imageViewObject.contentMode = .scaleAspectFit
//                imageViewObject.center =  CGPoint(x: backView.bounds.midX, y: backView.bounds.midY - 23)
//                backView.addSubview(imageViewObject)
//
//                //For Label.....Text, Color, Font, FontSize, Bounds, Lines, Alignment......
//                let noInternetLabel = UILabel(frame: CGRect(x: 0, y: 0, width: backView.bounds.width, height: 40))
//                noInternetLabel.text = errorString
//                noInternetLabel.font = UIFont(name: Constants().SFProTextBold, size: Constants().fontSize14)
//                noInternetLabel.textColor = UIColor.init(fromHexString: Constants().bluey_grey_two, 1)
//                noInternetLabel.numberOfLines = 2
//                noInternetLabel.textAlignment = .center
//                noInternetLabel.center =  CGPoint(x: backView.bounds.midX, y: backView.bounds.midY + 111)
//                backView.addSubview(noInternetLabel)
//
//                //For XButton........Text, Color, Font, FontSize, Bounds......
//                let closeButton = UIButton(frame: CGRect(x: 12, y: 32, width: 24, height: 24))
//                closeButton.backgroundColor = .white
//                closeButton.clipsToBounds = true
//                closeButton.setImage(UIImage.init(named: "Close"), for: .normal)
//
//                closeButton.tintColor = UIColor.init(fromHexString: Constants().secondaryColorString, 1)
//                closeButton.addTargetClosure(closure: { _ in
//                    for view in dynamicVC.view.subviews{
//                        if view.tag == 404{
//                            view.removeFromSuperview()
//                        }
//                    }
//                    if(dynamicVC.isKind(of: PatientINBOXViewController.self) || dynamicVC.isKind(of: SearchTabViewController.self)){
//                        dynamicVC.tabBarController?.tabBar.isHidden = false
//                    }
//                    if (dynamicVC.navigationController?.viewControllers[0].isKind(of: MainTabsViewController.self)) == true{
//                        let VC = dynamicVC.navigationController?.viewControllers[0] as! MainTabsViewController
//                        VC.backToTab = 0
//                        GenericHelper().customPopToRootViewController(dynamicVC, animation: true)
//                    }
//                    else if (dynamicVC.navigationController?.viewControllers[0].isKind(of: MainTabsDoctorViewController.self)) == true{
//                        let VC = dynamicVC.navigationController?.viewControllers[0] as! MainTabsDoctorViewController
//                        VC.selectedTabIndex = 1
//                       VC.segMentAction(index:1)
//                       GenericHelper().customPopToRootViewController(dynamicVC, animation: true)
//
//                    }
//
//                })
//                backView.addSubview(closeButton)
//
//                //For RetryButton........Text, Color, Font, FontSize, Bounds......
//                let retryButton = UIButton(frame: CGRect(x: 0, y: backView.center.y, width: 240, height: 48))
//                retryButton.backgroundColor = UIColor.init(fromHexString: Constants().primaryColorString, 1)
//                retryButton.layer.cornerRadius = retryButton.bounds.height / 2
//                retryButton.clipsToBounds = true
//                retryButton.setTitle("Retry", for: .normal)
//                retryButton.setTitleColor(UIColor.white, for: UIControlState.normal)
//                retryButton.titleLabel?.font = UIFont(name: Constants().SFProTextBold, size: Constants().fontSize16)
//                retryButton.center = CGPoint(x: backView.bounds.midX, y: backView.bounds.height - 44)
//                retryButton.addTargetClosure(closure: { button in
//
//                    if completionHandler != nil{
//                        for view in dynamicVC.view.subviews{
//                            if view.tag == 404{
//                                view.removeFromSuperview()
//                            }
//                        }
//                        completionHandler!(button)
//                        if(dynamicVC.isKind(of: PatientINBOXViewController.self) || dynamicVC.isKind(of: SearchTabViewController.self)){
//                            dynamicVC.tabBarController?.tabBar.isHidden = false
//                        }
//                    }
//                })
//                backView.addSubview(retryButton)
//
//                //Add UIView to ViewController.............
//                dynamicVC.view.addSubview(backView)
//                dynamicVC.view.bringSubview(toFront: backView)
//            }
//        }
//    }
//
//    func setStatusBar(_ colorString : String){
//
//        guard let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView else { return }
//        statusBar.backgroundColor = UIColor.init(fromHexString: colorString, 1.0)
//    }
//
    func nullToNil(value : AnyObject?) -> AnyObject? {
        if value is NSNull {
            return nil
        } else {
            return value
        }
    }
//
//    func nullToNilWithTypeCheck<T>(value : AnyObject? , type: T.Type) -> AnyObject?{
//
//        if value is NSNull {
//
//            return nil
//        } else {
//            if value is T {
//                if value is String{
//                    if (value as! String) != ""{
//                        return value
//                    }else{
//                        return nil
//                    }
//                }
//                if value is [Any]{
//                    if (value as! [Any]).count > 0{
//                        return value
//                    }else{
//                        return nil
//                    }
//                }
//                if value is Dictionary<String,Any>{
//                    if (value as! Dictionary<String,Any>).count > 0{
//                        return value
//                    }else{
//                        return nil
//                    }
//                }
//                return value
//            } else {
//                return nil
//            }
//        }
//    }
//
    func isNumeric(string: String) -> Bool
    {
        let number = Int(string)
        return number != nil
    }
    func isValidEmail(string:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: string)
    }
    func isNumberorNot(_ string:String) -> Bool {
        
        var final = Bool()
        
        let num = Int(string);
        
        if num != nil {
            final = true
        }
        else {
            final = false
        }
        return final
    }
    func addDoneButtonOnKeyboard(object : AnyObject)
    {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = UIBarStyle.default

        let flexSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIButton.init(type: .system)
        doneButton.frame = CGRect.init(x: 0, y: 0, width: 50, height: 50)
        doneButton.setTitle("Done", for: .normal)
        doneButton.tintColor = UIColor.init(hexString: Constants().light_navy_blue)

        doneButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: Constants().fontSize16)
        doneButton.addTargetClosure { _ in
            if let textField = object as? UITextField{
                textField.resignFirstResponder()
            }
            if let textView = object as? UITextView{
                textView.resignFirstResponder()
            }
        }

        let done: UIBarButtonItem = UIBarButtonItem.init(customView: doneButton)

        let items = NSMutableArray()
        items.add(flexSpace)
        items.add(done)

        doneToolbar.items = items as? [UIBarButtonItem]
        doneToolbar.sizeToFit()
        if let textField = object as? UITextField{
            textField.inputAccessoryView = doneToolbar
        }
        if let textView = object as? UITextView{
            textView.inputAccessoryView = doneToolbar
        }

    }
    
//    func applyBottomline(_ object : AnyObject) {
//
////        let linelbl = UILabel.init(frame: CGRect(x:,y:,width:,height:1))
//
//
//    }
//    func applyCornerRadius(_ object : AnyObject)
//    {
//        object.layer.masksToBounds = false;
//        object.layer.cornerRadius = 4.0
//    }
//
//    func applyLayerShadow(_ object : AnyObject)
//    {
//        object.layer.masksToBounds = false;
//        object.layer.shadowColor = UIColor.init(fromHexString: Constants().bluey_grey, 1).cgColor
//        object.layer.shadowOffset = CGSize.init(width: 0, height: 2)
//        object.layer.shadowRadius = 0.3
//        object.layer.shadowOpacity = 0.1
//    }
//    func applyLayerShadowDeep(_ object : AnyObject)
//    {
//        object.layer.masksToBounds = false;
//        object.layer.shadowColor = UIColor.init(fromHexString: Constants().bluey_grey, 1).cgColor
//        object.layer.shadowOffset = CGSize.init(width: 0, height: 5)
//        object.layer.shadowRadius = 0.5
//        object.layer.shadowOpacity = 0.5
//    }
//
//    func popUpGifSuccess( dynamicVC : UIViewController, title : String ,msg : String , cancelHandler: UIAlertAction){
//        let alert = UIAlertController(title: "\n\n\n\n\n\n\n\n\n", message: "", preferredStyle: UIAlertControllerStyle.alert)
//        let imgViewGif = UIImageView()
//        let gifManager = SwiftyGifManager(memoryLimit:100)
//
//            let rect = CGRect(x: 0 , y: 50, width: 270 , height: 100)
//            imgViewGif.frame = rect
//            imgViewGif.contentMode = .scaleAspectFit
//            let gifImage = UIImage(gifName: "LoaderCircle")
//            imgViewGif.setGifImage(gifImage, manager: gifManager, loopCount: -1)
//            alert.view.addSubview(imgViewGif)
//
//            dynamicVC.present(alert, animated: true, completion: nil)
//            let delayTime = DispatchTime.now() + Double(Int64(0.27 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
//            DispatchQueue.main.asyncAfter(deadline: delayTime){
//            let gifImage = UIImage(gifName: "SuccessWithLoader")
//            imgViewGif.setGifImage(gifImage, manager: gifManager, loopCount: 1)
//            let rect = CGRect(x: 0 , y: 180, width: 270 , height: 30)
//            let labelTitle = UILabel.init(frame: rect)
//            labelTitle.text = title
//            labelTitle.textAlignment = .center
//            labelTitle.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize18)
//            labelTitle.textColor = UIColor.init(fromHexString: Constants().successColor , 1)
//            alert.view.addSubview(labelTitle)
//
//            // your code here
//            let attachment = NSTextAttachment()
//            attachment.image = UIImage.init(named: "Cancel")
//
//            let attachmentString =  NSAttributedString.init(attachment: attachment)
//
//            let myString = NSMutableAttributedString.init()
//
//            myString.append(attachmentString)
//            let cancelAction = cancelHandler
//            alert.addAction(cancelAction)
//            guard let label = (cancelAction.value(forKey: "__representer") as AnyObject).value(forKey: "label") as? UILabel else { return }
//            label.attributedText = myString
//            let attributedString = NSAttributedString(string: msg, attributes: [
//                NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, //your font here
//                NSForegroundColorAttributeName : UIColor.black
//                ])
//
//            alert.setValue(attributedString, forKey: "attributedMessage")
//        }
//    }
//
//    func popUpGif( dynamicVC : UIViewController, imgViewGif : UIImageView, alert : UIAlertController, title : String ,msg : String ,state : Int, cancelHandler: UIAlertAction){
//
//
//        let gifManager = SwiftyGifManager(memoryLimit:100)
//        if state == 100{
//
//            let rect = CGRect(x: 0 , y: 50, width: 270 , height: 100)
//            imgViewGif.frame = rect
//            imgViewGif.contentMode = .scaleAspectFit
//            let gifImage = UIImage(gifName: "LoaderCircle")
//            imgViewGif.setGifImage(gifImage, manager: gifManager, loopCount: -1)
//            alert.view.addSubview(imgViewGif)
//
//            dynamicVC.present(alert, animated: true, completion: nil)
//        }
//        else if state == 1{
//        let gifImage = UIImage(gifName: "SuccessWithLoader")
//        imgViewGif.setGifImage(gifImage, manager: gifManager, loopCount: 1)
//        let rect = CGRect(x: 0 , y: 180, width: 270 , height: 30)
//        let labelTitle = UILabel.init(frame: rect)
//        labelTitle.text = title
//        labelTitle.textAlignment = .center
//        labelTitle.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize18)
//        labelTitle.textColor = UIColor.init(fromHexString: Constants().successColor , 1)
//        alert.view.addSubview(labelTitle)
//
//        // your code here
//        let attachment = NSTextAttachment()
//        attachment.image = UIImage.init(named: "Cancel")
//
//        let attachmentString =  NSAttributedString.init(attachment: attachment)
//
//        let myString = NSMutableAttributedString.init()
//
//        myString.append(attachmentString)
//        let cancelAction = cancelHandler
//        alert.addAction(cancelAction)
//        guard let label = (cancelAction.value(forKey: "__representer") as AnyObject).value(forKey: "label") as? UILabel else { return }
//        label.attributedText = myString
//        let attributedString = NSAttributedString(string: msg, attributes: [
//            NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, //your font here
//            NSForegroundColorAttributeName : UIColor.black
//            ])
//
//        alert.setValue(attributedString, forKey: "attributedMessage")
//        }else if state == 0{
//            let gifImage = UIImage(gifName: "ErrorithLoader")
//            imgViewGif.setGifImage(gifImage, manager: gifManager, loopCount: 1)
//            let rect = CGRect(x: 0 , y: 180, width: 270 , height: 30)
//            let labelTitle = UILabel.init(frame: rect)
//            labelTitle.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize18)
//            labelTitle.text = title
//            labelTitle.textColor = UIColor.init(fromHexString: Constants().errorColor , 1)
//            labelTitle.textAlignment = .center
//            alert.view.addSubview(labelTitle)
//            // your code here
//            let attachment = NSTextAttachment()
//            attachment.image = UIImage.init(named: "Cancel")
//
//            let attachmentString =  NSAttributedString.init(attachment: attachment)
//
//            let myString = NSMutableAttributedString.init()
//
//            myString.append(attachmentString)
//            let cancelAction = cancelHandler
//                //UIAlertAction(title: "", style: UIAlertActionStyle.destructive) { (result : UIAlertAction) -> Void in
//             //   dynamicVC.dismiss(animated: true, completion: nil)
//            //}
//            alert.addAction(cancelAction)
//            guard let label = (cancelAction.value(forKey: "__representer") as AnyObject).value(forKey: "label") as? UILabel else { return }
//            label.attributedText = myString
//
//
//            let attributedString = NSAttributedString(string: msg, attributes: [
//                NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, //your font here
//                NSForegroundColorAttributeName : UIColor.black
//                ])
//
//            alert.setValue(attributedString, forKey: "attributedMessage")
//
//        }else if state == 101
//        {
//            let gifImage = UIImage(gifName: "ErrorithLoader")
//            imgViewGif.setGifImage(gifImage, manager: gifManager, loopCount: 1)
//            let rect = CGRect(x: 0 , y: 180, width: 270 , height: 30)
//            let labelTitle = UILabel.init(frame: rect)
//            labelTitle.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize18)
//            labelTitle.text = title
//            labelTitle.textColor = UIColor.init(fromHexString: Constants().slate_grey , 1)
//            labelTitle.textAlignment = .center
//            alert.view.addSubview(labelTitle)
//            // your code here
//            let attachment = NSTextAttachment()
//            attachment.image = UIImage.init(named: "Cancel")
//
//            let attachmentString =  NSAttributedString.init(attachment: attachment)
//
//            let myString = NSMutableAttributedString.init()
//
//            myString.append(attachmentString)
//            let cancelAction = cancelHandler
//            //UIAlertAction(title: "", style: UIAlertActionStyle.destructive) { (result : UIAlertAction) -> Void in
//            //   dynamicVC.dismiss(animated: true, completion: nil)
//            //}
//            alert.addAction(cancelAction)
//            guard let label = (cancelAction.value(forKey: "__representer") as AnyObject).value(forKey: "label") as? UILabel else { return }
//            label.attributedText = myString
//
//
//            let attributedString = NSAttributedString(string: msg, attributes: [
//                NSFontAttributeName : UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)!, //your font here
//                NSForegroundColorAttributeName : UIColor.black
//                ])
//
//            alert.setValue(attributedString, forKey: "attributedMessage")
//
//        }
//    }
//
//    func errorPopGif(_ vc : UIViewController,title : String ,msg : String , handler: UIAlertAction){
//        DispatchQueue.main.async {
//            let alert = UIAlertController(title: "\n\n\n\n\n\n\n\n\n", message: "", preferredStyle: UIAlertControllerStyle.alert)
//            let imgViewGif = UIImageView()
//            GenericHelper().popUpGif(dynamicVC: vc, imgViewGif: imgViewGif, alert: alert, title: "", msg: "", state: 100, cancelHandler: UIAlertAction.init())
//
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
//                GenericHelper().popUpGif(dynamicVC: vc, imgViewGif: imgViewGif, alert: alert, title: title, msg: msg , state: 0, cancelHandler: handler)
//            }
//        }
//    }
//
    //Present
    func customPush(_ dynamicVC : UIViewController, viewControler: UIViewController, animation : Bool){
        /*let transition = CATransition()
        transition.duration = 0.5
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromTop
        dynamicVC.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        dynamicVC.navigationController?.pushViewController(viewControler, animated: animation)
    }
    //dismiss
    func customPop(_ dynamicVC : UIViewController, to viewController: AnyClass?, animation : Bool){

        if let vc = viewController{
            for viewController in (dynamicVC.navigationController?.viewControllers)!{
                if viewController.isKind(of: vc) {
                    let controller = viewController
                    dynamicVC.navigationController?.dismiss(animated: true, completion: nil)
                    dynamicVC.navigationController?.popToViewController(controller, animated: animation)
                }
            }
        }else{
            dynamicVC.navigationController?.dismiss(animated: true, completion: nil)
            dynamicVC.navigationController?.popViewController(animated: animation)
        }
    }

    func customPopToRootViewController(_ dynamicVC : UIViewController, animation : Bool){
       /* let transition = CATransition()
        transition.duration = 0.5
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromBottom
        dynamicVC.navigationController?.view.layer.add(transition, forKey: kCATransition)*/
        dynamicVC.navigationController?.popToRootViewController(animated: animation)
    }

//    func stringHavingSpecialCharacters(_ inputString:  String, _ type: String?, spaceCheck : Bool,allowSpecialChar  : String?) -> Bool{
//        var isValid = true
//        let trimmedString = inputString.trimmingCharacters(in: .whitespacesAndNewlines)
//        if type != nil{
//            if type == "number"{
//                var characterset = CharacterSet(charactersIn: "0123456789")
//                if !spaceCheck{
//                    characterset.insert(charactersIn: " ")
//                }
//                if allowSpecialChar != nil{
//                    characterset.insert(charactersIn: allowSpecialChar ?? "")
//                }
//                if trimmedString.rangeOfCharacter(from: characterset.inverted) != nil {
//                    isValid = false
//                }
//            }else if type == "char"{
//                var characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
//                if !spaceCheck{
//                    characterset.insert(charactersIn: " ")
//                }
//                if allowSpecialChar != nil{
//                    characterset.insert(charactersIn: allowSpecialChar ?? "")
//                }
//                if trimmedString.rangeOfCharacter(from: characterset.inverted) != nil {
//                    isValid = false
//                }
//            }
//        }else{
//            var characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
//            if !spaceCheck{
//                characterset.insert(charactersIn: " ")
//            }
//            if allowSpecialChar != nil{
//                characterset.insert(charactersIn: allowSpecialChar ?? "")
//            }
//            if trimmedString.rangeOfCharacter(from: characterset.inverted) != nil {
//                isValid = false
//            }
//        }
//        return isValid
//    }
//
//
//    //Convert Date into MilliSeconds
//    func ConvertDateInMiliseconds(dateString:String, dateFormat:String) -> Int {
//
//        let dateFormatter = DateFormatter()
//
//        dateFormatter.dateFormat = dateFormat
//
//        let Ndate = dateFormatter.date(from: dateString as String)
//
//        //        let currentDate = Date()
//        let dateLocal = Ndate?.addingTimeInterval(+Constants().offsetTime)
//
//        let since1970 = dateLocal?.timeIntervalSince1970
//
//        return Int(since1970! * 1000)
//    }
//
//    func DoctorConvertDateInMiliseconds(dateString:String, dateFormat:String) -> Int {
//
//        let dateFormatter = DateFormatter()
//
//        dateFormatter.dateFormat = dateFormat
//
//        let Ndate = dateFormatter.date(from: dateString as String)
//
//        //        let currentDate = Date()
//        let since1970 = Ndate?.timeIntervalSince1970.adding(+Constants().offsetTime)
//
//        return Int(since1970! * 1000)
//
//    }
//    //Remove Elements Tag Based
//    func removeObj(tagg:Int, mview:UIView) {
//
//        let subViews = mview.subviews
//
//        for subview in subViews {
//
//            if subview.tag == tagg{
//
//                subview.removeFromSuperview()
//            }
//        }
//    }
//    //MARK: Get Age in Yeras, Months, Days...
//    func getAge(startDate:String, endDate:String, dateFormat:String) -> String {
//
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = dateFormat
//        let dateStart = dateFormatter.date(from: startDate)
//        let datesEnd = dateFormatter.date(from: endDate)
//
//        var yearValue = Int()
//        var monthValue = Int()
//        var daysValue = Int()
//        var finalAge = String()
//
//        let getYears = Calendar.current.dateComponents([.year], from: dateStart!, to: datesEnd!).year
//        yearValue = getYears!
//
//        if yearValue != 0 {
//            if yearValue < 2{
//                finalAge = "\(yearValue) \("Year")"
//            }else{ finalAge = "\(yearValue) \("Years")" }
//        }else
//        {
//            let getMonths = Calendar.current.dateComponents([.month], from: dateStart!, to: datesEnd!).month
//            monthValue = getMonths!
//            if monthValue != 0{
//                if monthValue < 2{
//                    finalAge = "\(monthValue) \("Month")"
//                }else{ finalAge = "\(monthValue) \("Months")" }
//            }
//            else
//            {
//                let getDayss = Calendar.current.dateComponents([.day], from: dateStart!, to: datesEnd!).day
//                daysValue = getDayss!
//                if daysValue < 2{
//                    finalAge = "\(daysValue) \("Day")"
//                }else
//                {finalAge = "\(daysValue) \("Days")"}
//            }
//        }
//
//        return finalAge
//
//    }
    
    func getCurrentDate(_ dateFormat:String) -> String {

        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = dateFormat
        let result = formatter.string(from: date)

        return result
    }
//    func noInternetPopUpView(internetview:UIView) {
//
//    }
//
//
//
//    func convertToCSV(arrayObject : [Any]) -> String? {
//        var csvStr = ""
//        for obj in arrayObject{
//            if !(obj is [Any]) && !(obj is Dictionary<String,Any>){
//                csvStr += "\(obj), "
//            }
//        }
//        if csvStr != ""{
//            csvStr.characters.removeLast(2)
//            return csvStr
//        }else{
//            return nil
//        }
//    }
//
//    func convertCSVToArray(str : String) -> [String]? {
//        var csvArray = [String]()
//
//        if str != ""{
//            csvArray = str.characters.split{$0 == ","}.map(String.init)
//            return csvArray
//        }else{
//            return nil
//        }
//    }
//
//    //=====================================================//
//    //MARK: CustomPopUp for Save & Exit
//    //=====================================================//
//    func showPopupViewforSaveAndExit(_ title: String,_ message: String, _ btnSaveTitle: String,_ btnExitTitle : String, btnSaveAction: @escaping UIButtonTargetClosure, btnExitAction: @escaping UIButtonTargetClosure,_ displayView: UIView){
//
//        //--------------* Main View *------------//
//
//        let viewtoshowViewPopUp = UIView()
//        viewtoshowViewPopUp.tag = 99
//        viewtoshowViewPopUp.backgroundColor = UIColor.init(fromHexString: Constants().slate_grey, 0.5)
//        viewtoshowViewPopUp.frame = CGRect(x:0, y:0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
//
//         //--------------* Inner View *------------//
//
//        let backPopView = UIView.init(frame: CGRect(x:20, y:viewtoshowViewPopUp.frame.size.height / 3, width:UIScreen.main.bounds.width - 40,height:280))
//
//
//        //--------------* Title Label *------------//
//
//        let labelTitle = UILabel.init(frame: CGRect(x:20, y:15, width:backPopView.frame.size.width - 40,height:50))
//        labelTitle.textColor = UIColor.init(hexString: Constants().secondaryColorString)
//        labelTitle.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize16)
//        labelTitle.text = title
//        labelTitle.textAlignment = .center
//
//        backPopView.addSubview(labelTitle)
//
//        //--------------* Message Label *------------//
//
//        let YmsgLabel = labelTitle.frame.origin.y + labelTitle.frame.size.height + 15.0
//        let messageLBl = UILabel.init(frame: CGRect(x:10, y:YmsgLabel, width:backPopView.frame.size.width - 20,height:60))
//        messageLBl.textColor = UIColor.black
//        messageLBl.font = UIFont.init(name: Constants().latoRegular, size: Constants().fontSize14)
//        messageLBl.text = message
//        messageLBl.numberOfLines = 0
//        messageLBl.sizeToFit()
//        messageLBl.textAlignment = .center
//
//        backPopView.addSubview(messageLBl)
//
//        //--------------* Button Save *------------//
//
//        let YbtnSave = messageLBl.frame.origin.y + messageLBl.frame.size.height + 20.0
//        let btnSave = UIButton.init(frame: CGRect(x:30,y:YbtnSave,width:backPopView.frame.size.width - 60,height:40))
//        btnSave.layer.cornerRadius = 20.0
//        btnSave.setTitle(btnSaveTitle, for: .normal)
//        btnSave.backgroundColor = UIColor.init(fromHexString: Constants().primaryColorString, 1.0)
//        btnSave.setTitleColor(.white, for: .normal)
//        btnSave.titleLabel?.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize16)
//        GenericHelper().applyLayerShadow(btnSave)
//        btnSave.addTargetClosure(closure: btnSaveAction)
//
//        backPopView.addSubview(btnSave)
//
//
//        //--------------* Button Exit *------------//
//
//        let YbtnExit = btnSave.frame.origin.y + btnSave.frame.size.height + 10.0
//        let btnExit = UIButton.init(frame: CGRect(x:30,y:YbtnExit,width:backPopView.frame.size.width - 60,height:40))
//        btnExit.layer.cornerRadius = 20.0
//        btnExit.setTitle(btnExitTitle, for: .normal)
//        btnExit.backgroundColor = UIColor.init(fromHexString: Constants().primaryColorString, 1.0)
//        btnExit.setTitleColor(.white, for: .normal)
//        btnExit.titleLabel?.font = UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize16)
//        GenericHelper().applyLayerShadow(btnExit)
//        btnExit.addTargetClosure(closure: btnExitAction)
//
//        backPopView.addSubview(btnExit)
//
//
//        //--------------* Label Sapprator *------------//
//
//        let labelSapprator = UIButton.init(frame: CGRect(x:0,y:YbtnExit + 48 ,width:backPopView.frame.size.width,height:1))
//        labelSapprator.backgroundColor = UIColor.init(fromHexString: Constants().pale_grey_four, 1.0)
//
//        backPopView.addSubview(labelSapprator)
//
//         //--------------* Button Cancel *------------//
//
//        let btnCancel = UIButton.init(frame: CGRect(x:(backPopView.frame.size.width / 2) - 20,y:YbtnExit + 57 ,width:40,height:40))
//        btnCancel.setImage(UIImage.init(named: "Cancel"), for: .normal)
//        btnCancel.addTargetClosure { button in
//            if let view = displayView.viewWithTag(99){
//                view.removeFromSuperview()
//            }
//        }
//        backPopView.addSubview(btnCancel)
//
//        //--------------* InnerView Size *------------//
//
//        let yforView = btnCancel.frame.origin.y + btnCancel.frame.size.height + 8.0
//        backPopView.frame.size = CGSize(width:UIScreen.main.bounds.width - 40,height:yforView)
//        backPopView.backgroundColor = UIColor.white
//        viewtoshowViewPopUp.addSubview(backPopView)
//        displayView.addSubview(viewtoshowViewPopUp)
//
//    }
//
//    //MARK:Custom PopUp
//
    func showPopUpview(title:String, message:String, yesBtn:Bool, noBtn:Bool, yesAct: @escaping UIButtonTargetClosure,noAct: @escaping UIButtonTargetClosure, yesTitle:String, noTitle:String, mView:UIView) {

        let viewtoshowViewPopUp = UIView()

        viewtoshowViewPopUp.tag = 99

        viewtoshowViewPopUp.frame = CGRect(x:0, y:0, width:mView.frame.size.width, height:mView.frame.size.height)

       viewtoshowViewPopUp.backgroundColor = UIColor.init(fromHexString: Constants().slate_grey, 0.5)


        viewtoshowViewPopUp.frame = CGRect(x:0, y:0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        let popUp = UIView()

        popUp.frame = CGRect(x:0, y:0, width: UIScreen.main.bounds.width - 40, height: 175)

        popUp.tag = 100

        popUp.backgroundColor = UIColor.white

        let titleLbl = UILabel()
        let messageLbl = UILabel()
        let linelbl = UILabel()

        if title != ""
        {
            titleLbl.font = UIFont.init(name: Constants().defaultAvenierSemiBold, size: Constants().fontSize16)

            titleLbl.frame = CGRect(x:30,y:25, width:popUp.frame.size.width - 60,height:50)
            titleLbl.text = title
            titleLbl.textAlignment = .center
            titleLbl.textColor = UIColor.init(fromHexString: "#2a577f", 1.0)
            titleLbl.numberOfLines = 0
            titleLbl.sizeToFit()
            titleLbl.frame.size.width = popUp.frame.size.width - 60


        }
        else
        {
            titleLbl.frame = CGRect(x:popUp.frame.size.width * 0.5 - 100,y:25, width:200,height:0)

        }

        let yforMessage = titleLbl.frame.origin.y + titleLbl.frame.size.height

        if message != "" {

            messageLbl.frame = CGRect(x:30, y:yforMessage + 5.0, width:popUp.frame.size.width - 60, height:40)

            messageLbl.text = message
            messageLbl.textAlignment = .center
            messageLbl.textColor = UIColor.init(fromHexString: Constants().dark_grey, 1.0)
            messageLbl.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize14)
            messageLbl.numberOfLines = 0
            messageLbl.sizeToFit()

            messageLbl.frame.size.width = popUp.frame.size.width - 60



        }
        else
        {
            messageLbl.frame = CGRect(x:30,y:yforMessage, width:0,height:0)

        }

        let yforLineLabel = messageLbl.frame.origin.y + messageLbl.frame.size.height + 30.0

        linelbl.frame = CGRect(x:0, y:yforLineLabel, width:popUp.frame.size.width, height:1)

        linelbl.backgroundColor = UIColor.init(fromHexString: "#c6daeb", 1.0)

        let yPositionBtn = linelbl.frame.origin.y + linelbl.frame.size.height

        let buttonYes = UIButton()
        let buttonNo = UIButton()
        var heightforPopupView = CGFloat()


        if yesBtn == true && noBtn == true {

            buttonYes.frame = CGRect(x:popUp.frame.size.width/2 + 40, y:yPositionBtn, width:popUp.frame.size.width/2 - 50, height:45)

            buttonYes.backgroundColor = UIColor.clear

            if yesTitle != "" {

               //yesTitle
                buttonYes.setTitle(yesTitle, for: .normal)


            }
            else
            {
                buttonYes.setTitle("Yes", for: .normal)
                buttonYes.setImage(UIImage(named:"Confirm"), for: .normal)


            }

            buttonYes.setTitleColor(UIColor.init(fromHexString: "#2a577f", 1.0), for: .normal)

            buttonNo.frame = CGRect(x:45, y:yPositionBtn, width:popUp.frame.size.width/2 - 50, height:45)

            buttonNo.backgroundColor = UIColor.clear

            if noTitle != ""
            {
                buttonNo.setTitle(noTitle, for: .normal)

            }
            else
            {
                buttonNo.setTitle("No", for: .normal)
                buttonNo.setImage(UIImage(named:"Cancel"), for: .normal)


            }

            buttonNo.setTitleColor(UIColor.init(fromHexString: "#2a577f", 1.0), for: .normal)

            heightforPopupView = buttonYes.frame.origin.y + buttonYes.frame.size.height

        }
        else if yesBtn == true
        {
            buttonYes.frame = CGRect(x:popUp.frame.size.width/2 - 40, y:yPositionBtn, width:popUp.frame.size.width/2 - 50, height:45)

            buttonYes.backgroundColor = UIColor.clear

            if yesTitle != "" {

                //yesTitle
                buttonYes.setTitle(yesTitle, for: .normal)


            }
            else
            {
                buttonYes.setTitle("Yes", for: .normal)
                buttonYes.setImage(UIImage(named:"Confirm"), for: .normal)


            }
            buttonYes.setTitleColor(UIColor.init(fromHexString: "#2a577f", 1.0), for: .normal)

            buttonNo.frame = CGRect(x:popUp.frame.size.width/2, y:yPositionBtn, width:0, height:0)

            heightforPopupView = buttonYes.frame.origin.y + buttonYes.frame.size.height



        }
        else if noBtn == true
        {
            buttonNo.frame = CGRect(x:popUp.frame.size.width/2 - 40, y:yPositionBtn, width:popUp.frame.size.width/2 - 50, height:45)

            buttonNo.backgroundColor = UIColor.clear

            if noTitle != ""
            {
                buttonNo.setTitle(noTitle, for: .normal)

            }
            else
            {
                buttonNo.setTitle("No", for: .normal)
                buttonNo.setImage(UIImage(named:"Cancel"), for: .normal)


            }
            buttonNo.setTitleColor(UIColor.blue, for: .normal)

            buttonYes.frame = CGRect(x:popUp.frame.size.width/2, y:yPositionBtn, width:0, height:0)

            heightforPopupView = buttonNo.frame.origin.y + buttonYes.frame.size.height

        }
        else
        {
            buttonYes.frame = CGRect(x:popUp.frame.size.width/2, y:yPositionBtn, width:0, height:0)
            buttonNo.frame = CGRect(x:popUp.frame.size.width/2, y:yPositionBtn, width:0, height:0)
            heightforPopupView = buttonNo.frame.origin.y + buttonYes.frame.size.height

        }

        let yesbTNACT = yesAct
        let nobTNACT = noAct

        buttonYes.addTargetClosure(closure: yesbTNACT)
        buttonNo.addTargetClosure(closure: nobTNACT)

        let insetAmount:CGFloat = 30
        buttonNo.imageEdgeInsets = UIEdgeInsets(top: 0, left: -insetAmount, bottom: 0, right: insetAmount)
        buttonNo.titleEdgeInsets = UIEdgeInsets(top: 0, left: -60, bottom: 0, right: -insetAmount)

        let yinsetAmount:CGFloat = 30
        buttonYes.imageEdgeInsets = UIEdgeInsets(top: 0, left: -yinsetAmount, bottom: 0, right: yinsetAmount)
        buttonYes.titleEdgeInsets = UIEdgeInsets(top: 0, left: -60, bottom: 0, right: -yinsetAmount)

        popUp.frame = CGRect(x:0,y:0,width:UIScreen.main.bounds.width - 40,height:heightforPopupView)
        popUp.layer.cornerRadius = 5.0
        popUp.layer.masksToBounds = true

        popUp.addSubview(titleLbl)
        popUp.addSubview(messageLbl)
        popUp.addSubview(linelbl)
        popUp.addSubview(buttonYes)
        popUp.addSubview(buttonNo)
        popUp.center = viewtoshowViewPopUp.center
        viewtoshowViewPopUp.addSubview(popUp)
        mView.addSubview(viewtoshowViewPopUp)

//
    }
//
//    func checkInternetAvailable(dynamicVC: UIViewController){
//
//        if ConnectivityHelper().isInternetAvailable(){
//            for view in dynamicVC.view.subviews{
//                if view.tag == 404 {
//                    view.removeFromSuperview()
//                }
//            }
//        }else{
//
//            respRedirect(errorString: Constants().reachabilityerrorString , dynamicVC: dynamicVC, errorCodeString: ErrorCode.rechability.rawValue, completionHandler: { button in
//                self.checkInternetAvailable(dynamicVC: dynamicVC)
//            })
//        }
//    }
//
//    func checkInternet(dynamicVC: UIViewController, Execution: @escaping () -> Void){
//
//        if ConnectivityHelper().isInternetAvailable(){
//
//            for view in dynamicVC.view.subviews{
//                if view.tag == 404 {
//                    view.removeFromSuperview()
//                }
//            }
//
//            Execution()
//
//        }else{
//
//            respRedirect(errorString: Constants().reachabilityerrorString , dynamicVC: dynamicVC, errorCodeString: ErrorCode.rechability.rawValue, completionHandler: { button in
//
//                self.checkInternet(dynamicVC: dynamicVC, Execution: Execution)
//
//            })
//        }
//    }
//
//    //FIXME: UserData
//    //Accounts Retrieved
//
//    func checkUserType(type : String) -> Bool{
//        var userType = String()
//        if let data = UserDefaults.standard.object(forKey: "userData")
//        {
//            let userdatadecoded = NSKeyedUnarchiver.unarchiveObject(with: data as! Data)
//
//            let userDataDict = userdatadecoded as! Dictionary<String, Any>
//
//            if let accountsDict = GenericHelper().nullToNilWithTypeCheck(value: userDataDict["accounts"] as AnyObject, type: [Any].self) as? [Any]{
//                if let usertype = GenericHelper().nullToNilWithTypeCheck(value: (accountsDict[0] as! NSDictionary).value(forKey: "usertype") as AnyObject, type: String.self) as? String{
//                    userType = usertype
//                }
//            }
//        }
//        return userType.caseInsensitiveCompare(type) == ComparisonResult.orderedSame
//    }
//
//    func isRegexValid(testStr:String) -> Bool {
//        let regEx = "/^\\d{1,3}\\/\\d{1,3}$/"
//        let test = NSPredicate(format:"SELF MATCHES %@", regEx)
//        return test.evaluate(with: testStr)
//    }
//
//    func valueCheck(_ d: String) -> Bool {
//        var result = false
//        do {
//            let regex = try NSRegularExpression(pattern: "^\\d{1,3}\\/\\d{1,3}$", options: [])
//            let results = regex.matches(in: String(d), options: [], range: NSMakeRange(0, String(d).characters.count))
//            if results.count > 0 {result = true}
//        } catch let error as NSError {
//            print("invalid regex: \(error.localizedDescription)")
//        }
//        return result
//    }
//    func applyBarbuttonTitle(title:UIBarButtonItem) {
//
//         title.setTitleTextAttributes([NSFontAttributeName: UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize16)!, NSForegroundColorAttributeName:UIColor.init(fromHexString: Constants().secondaryColorString, 1.0)], for: UIControlState.disabled)
//          title.setTitleTextAttributes([NSFontAttributeName: UIFont.init(name: Constants().SFProTextBold, size: Constants().fontSize16)!, NSForegroundColorAttributeName:UIColor.init(fromHexString: Constants().secondaryColorString, 1.0)], for: UIControlState.normal)
//
//
//    }
//
    func dowNLoadimagefromURL(_ urlStr:String, _ placeHolderIMG:String) -> UIImage {

        var finalIMG = UIImage()

        let finalURL = URL(string:urlStr)

        let imageData:Data = try! Data(contentsOf: finalURL!)

        if imageData != nil {

            DispatchQueue.main.async {
                
                let image = UIImage(data: imageData as Data)
                
                finalIMG = image!
            }

        }else{

            finalIMG = UIImage(named:placeHolderIMG)!
        }

        return finalIMG
    }
//
//    //MARK: Close PopUp
//    func closePopup(_ vc : UIViewController){
//        if let view = vc.view.viewWithTag(99){
//            view.removeFromSuperview()
//        }
//    }
//
//    //MARK:TimeSlot Logic
//
//    func getTimeSlot(timeData:Int) -> String {
//
//        var finalTime = String()
//
//        if timeData < 24 {
//
//            let acTime:Double = Double(timeData)
//
//            let Bytwo:Double = acTime / 2
//
//            let isInteger = Bytwo.truncatingRemainder(dividingBy: 1) == 0
//
//            if isInteger{
//                let finalValUe:Int = Int(Bytwo)
//                finalTime = "\(finalValUe)\(":00 AM")"
//
//            }else{
//
//                let finalValUe:Int = Int(Bytwo)
//                finalTime = "\(finalValUe)\(":30 AM")"
//            }
//
//        }else{
//
//            let acTime:Double = Double(timeData)
//            let Bytwo:Double = acTime / 2
//            finalTime = getTimeSTR(timevalue: Bytwo)
//        }
//
//        return finalTime
//    }
//
//
//    func getTimeSTR(timevalue:Double) -> String {
//
//        var finalllT = String()
//
//        if timevalue == 12.0 {
//
//            finalllT = "12:00 PM"
//        }
//        else if timevalue == 12.5 {
//
//            finalllT = "12:30 PM"
//        }
//        else if timevalue == 13.0 {
//
//            finalllT = "01:00 PM"
//        }
//        else if timevalue == 13.5 {
//
//            finalllT = "01:30 PM"
//        }
//        else if timevalue == 14.0 {
//
//            finalllT = "02:00 PM"
//        }else if timevalue == 14.5 {
//
//            finalllT = "02:30 PM"
//        }else if timevalue == 15.0 {
//
//            finalllT = "03:00 PM"
//        }else if timevalue == 15.5 {
//
//            finalllT = "03:30 PM"
//        }else if timevalue == 16.0 {
//
//            finalllT = "04:00 PM"
//        }else if timevalue == 16.5 {
//
//            finalllT = "04:30 PM"
//        }
//        else if timevalue == 17.0 {
//
//            finalllT = "05:00 PM"
//        }else if timevalue == 17.5 {
//
//            finalllT = "05:30 PM"
//        }else if timevalue == 18.0 {
//
//            finalllT = "06:00 PM"
//        }else if timevalue == 18.5 {
//
//            finalllT = "06:30 PM"
//        }else if timevalue == 19.0 {
//
//            finalllT = "07:00 PM"
//        }else if timevalue == 19.5 {
//
//            finalllT = "07:30 PM"
//        }
//        else if timevalue == 20.0 {
//
//            finalllT = "08:00 PM"
//        }else if timevalue == 20.5 {
//
//            finalllT = "08:30 PM"
//        }
//        else if timevalue == 21.0 {
//
//            finalllT = "09:00 PM"
//        }else if timevalue == 21.5 {
//
//            finalllT = "09:30 PM"
//        }
//        else if timevalue == 22.0 {
//
//            finalllT = "10:00 PM"
//        }else if timevalue == 22.5 {
//
//            finalllT = "10:30 PM"
//        }else if timevalue == 23.0 {
//
//            finalllT = "11:00 PM"
//        }
//        else if timevalue == 23.5 {
//
//            finalllT = "11:30 PM"
//        }
//        else if timevalue == 24.0 {
//
//            finalllT = "12:00 AM"
//        }
//
//
//        return finalllT
//    }
//
//    //MARK: Convert Dict to String --> START
//
//    func dictIntoString(allData:[String:String]) -> String {
//
//        var finalString = String()
//
//        var DictAllparameters = [String: String]()
//
//        do {
//            let jsonData = try JSONSerialization.data(withJSONObject: allData, options: .prettyPrinted)
//
//            let decoded = try JSONSerialization.jsonObject(with: jsonData, options: [])
//
//            if let dictFromJSON = decoded as? [String:String] {
//
//                DictAllparameters = dictFromJSON
//
//            }
//        } catch {
//            print(error.localizedDescription)
//        }
//
//        finalString = self.convertToJsonString(json: DictAllparameters)!
//
//        return finalString
//    }
//
//    func convertToJsonString(json: [String: Any]) -> String? {
//        do {
//            let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
//            return String(data: jsonData, encoding: .utf8)
//        } catch {
//            print(error.localizedDescription)
//        }
//        return nil
//    }
    //<-- END
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
}

