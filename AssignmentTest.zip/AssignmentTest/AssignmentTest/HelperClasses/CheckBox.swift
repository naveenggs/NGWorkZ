//
//  CheckBox.swift
//  checkbox
//
//  Created by kent on 9/27/14.
//  Copyright (c) 2014 kent. All rights reserved.
//
//Version 2.0 new features
//Added IBInspectable property so the checkbox can be turned on and off in interface builder.

import UIKit

class CheckBox: UIButton {
    
    //images
    var checkedImage = UIImage(named: "Check")
    var unCheckedImage = UIImage(named: "UncheckRounded")
    
    //bool propety
    @IBInspectable var isChecked:Bool = false{
        didSet{
            self.updateImage()
        }
    }

    @IBInspectable var checkImage:UIImage = UIImage(named: "Check")!{
        didSet{
            checkedImage = checkImage
            self.updateImage()
        }
    }
    
    @IBInspectable var uncheckImage:UIImage = UIImage(named: "UncheckRounded")!{
        didSet{
            unCheckedImage = uncheckImage
            self.updateImage()
        }
    }
    
    override func awakeFromNib() {
        self.addTarget(self, action: #selector(CheckBox.buttonClicked(_:)), for: UIControl.Event.touchUpInside)
            self.updateImage()
    }
    
    
    func updateImage() {
        if isChecked == true{
           // self.tintColor = UIColor.init(fromHexString: Constants().primaryColorString, 1)
            self.setImage(checkedImage, for: UIControl.State())
        }else{
          //  self.tintColor = UIColor.init(fromHexString: Constants().dark_grey, 1)
            self.setImage(unCheckedImage, for: UIControl.State())
        }

    }

    @objc func buttonClicked(_ sender:UIButton) {
        if(sender == self){
            isChecked = !isChecked
        }
    }

}
