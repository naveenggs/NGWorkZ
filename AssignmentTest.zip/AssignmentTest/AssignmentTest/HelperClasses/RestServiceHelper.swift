//
//  RestServiceHelper.swift
//  ClientApp
//
//  Created by Naveen Gundu on 21/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import Foundation

enum RestFullTypes : String{
    case GET = "GET";
    case POST = "POST";
    var description: String {
        return self.rawValue
    }
}

func sendRequestCustomBody(urlRequest: URLRequest, parameters: [String: AnyObject], completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionTask{
//    let systemVersion = UIDevice.current.systemVersion
//    //First get the nsObject by defining as an optional anyObject
//    var version = String()
//    if let text = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
//        print(text)
//        version = text
//    }
//    let deviceName = DeviceGuru.hardware()
//    let deviceInfoDict = ["ai" : ["appid" : "\(Bundle.main.bundleIdentifier ?? "")" , "vc" : "\(version)" , "vn" : "\(version)"] , "d" : ["c" : "APPLE" , "mn" : "\(deviceName)"], "os" : ["n" :  "\(UIDevice.current.systemName)" , "v" : "\(systemVersion)" ] , "ua" : "iOS"] as [String : Any]
//
//    let jsonData = try? JSONSerialization.data(withJSONObject: deviceInfoDict, options: .prettyPrinted)
//    var headerUserAgent = NSString(data: jsonData!, encoding: String.Encoding.utf8.rawValue)! as String
//    headerUserAgent = headerUserAgent.replacingOccurrences(of: "\n", with: "")
    
    var request : URLRequest = urlRequest
//    request.addValue(headerUserAgent, forHTTPHeaderField: "x-user-agent")
    
    if request.httpMethod == "POST"
    {
        
        //  request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options:.prettyPrinted)
        
    }
    else if request.httpMethod == "GET"
    {
        
    }
    else if request.httpMethod == "PUT"
    {
        if parameters.count != 0{
            request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options:.prettyPrinted)
        }

    }else if request.httpMethod == "DELETE"
    {
        request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options:.prettyPrinted)
    }
    URLCache.shared.removeAllCachedResponses()
    //Session Handling...
    let task = URLSession.shared.dataTask(with: request, completionHandler: completionHandler)
    
    task.resume()
    
    return task
}


func sendRequest(urlRequest: URLRequest, parameters: [String: AnyObject], completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionTask{
//    let systemVersion = UIDevice.current.systemVersion
    //First get the nsObject by defining as an optional anyObject
    var version = String()
    if let text = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
        print(text)
        version = text
    }
//    let deviceName = DeviceGuru.hardware()
//    let deviceInfoDict = ["ai" : ["appid" : "\(Bundle.main.bundleIdentifier ?? "")" , "vc" : "\(version)" , "vn" : "\(version)"] , "d" : ["c" : "APPLE" , "mn" : "\(deviceName)"], "os" : ["n" :  "\(UIDevice.current.systemName)" , "v" : "\(systemVersion)" ] , "ua" : "iOS"] as [String : Any]
//
//    let jsonData = try? JSONSerialization.data(withJSONObject: deviceInfoDict, options: .prettyPrinted)
//    var headerUserAgent = NSString(data: jsonData!, encoding: String.Encoding.utf8.rawValue)! as String
//    headerUserAgent = headerUserAgent.replacingOccurrences(of: "\n", with: "")
//
    var request : URLRequest = urlRequest
//    request.addValue(headerUserAgent, forHTTPHeaderField: "x-user-agent")
    
    if request.httpMethod == "POST"
    {
        
        request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options:.prettyPrinted)
        
    }
    else if request.httpMethod == "GET"
    {
        
    }
    else if request.httpMethod == "PUT"
    {
        
        request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options:.prettyPrinted)
        
    }else if request.httpMethod == "DELETE"
    {
        request.httpBody = try! JSONSerialization.data(withJSONObject: parameters, options:.prettyPrinted)
    }
    URLCache.shared.removeAllCachedResponses()
    //Session Handling...
    let task = URLSession.shared.dataTask(with: request, completionHandler: completionHandler)
    
    task.resume()
    
    return task
}

class RestFullHelper{
    //MARK: MultiPartData request
    
    func generateBoundaryString() -> String
    {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func createBody(parameters: [String: String],
                    boundary: String,
                    imageArray : [Any]) -> Data {
        var body = NSMutableData()
        
        let boundaryPrefix = "--\(boundary)\r\n"
        for (key, value) in parameters {
            body.appendString(boundaryPrefix)
            body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
            body.appendString("\(value)\r\n")
        }
        body = (RestFullHelper().createBodyForImageArray(boundaryPrefix: boundaryPrefix, body: body, imageArray: imageArray as! [Dictionary<String, Any>]))
        body.appendString("--".appending(boundary.appending("--")))
        return body as Data
    }
    
    func createBodyForImageArray(boundaryPrefix : String, body : NSMutableData, imageArray : [Dictionary<String,Any>]) -> NSMutableData{
        var i = 1
        for dict in imageArray {
            let data = dict["data"] as! Data
            let mimeType = dict["mimeType"] as! String
            let filename = dict["filename"] as! String
            body.appendString(boundaryPrefix)
           
            body.appendString("Content-Disposition: form-data; name=\"userprofile\"; filename=\"\(filename)\"\r\n")
        
            body.appendString("Content-Type: \(mimeType)\r\n\r\n")
            body.append(data)
            body.appendString("\r\n")
            i += 1
        }
        return body as NSMutableData
    }
}

//Conversion purpose Only
extension String {
    func stringByAddingPercentEncodingForURLQueryValue() -> String? {
        return self.addingPercentEncoding( withAllowedCharacters: .urlQueryAllowed)
    }
}

extension NSMutableData {
    func appendString(_ string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: false)
        append(data!)
    }
}

extension Dictionary {
    func stringFromHttpParameters() -> String {
        let parameterArray = self.map { (key, value) -> String in
            let percentEscapedKey = (key as! String).stringByAddingPercentEncodingForURLQueryValue()!
            let percentEscapedValue = String(format: "%@", value as! CVarArg).stringByAddingPercentEncodingForURLQueryValue()!
            return "\(percentEscapedKey)=\(percentEscapedValue)"
        }
        return parameterArray.joined(separator: "&")
    }
}

