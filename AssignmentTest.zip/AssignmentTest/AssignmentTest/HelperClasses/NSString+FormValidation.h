//
//  NSString+FormValidation.h
//  CheckApp
//
//  Created by Tushar on 04/08/16.
//  Copyright © 2016 CheckApp Healthcare Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FormValidation)

- (BOOL)isValidEmail;
- (BOOL)isValidName;
- (BOOL)isValidNumber;
- (BOOL)isEmpty;
- (BOOL)containsOnlySpaces;
- (BOOL)isValidPassword;
-(BOOL)isNumeric;
- (BOOL)isValidPin ;
-(NSString *)stringWithNonDigitsRemoved;
@end
