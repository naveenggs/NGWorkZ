//
//  UIkit+Extended.swift
//  ClientApp
//
//  Created by Naveen Gundu on 21/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import UIKit

typealias UIButtonTargetClosure = (UIButton) -> ()

typealias UnixTime = Double

class ClosureWrapper: NSObject {
    let closure: UIButtonTargetClosure
    init(_ closure: @escaping UIButtonTargetClosure) {
        self.closure = closure
    }
}

class UILabelPadding: UILabel {
    
//    let padding = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 0)
//    override func drawText(in rect: CGRect) {
//        super.drawText(in: UIEdgeInsetsInsetRect(rect, padding))
//    }
//
//    override var intrinsicContentSize : CGSize {
//        let superContentSize = super.intrinsicContentSize
//        let width = superContentSize.width + padding.left + padding.right
//        let heigth = superContentSize.height + padding.top + padding.bottom
//        return CGSize(width: width, height: heigth)
//    }
    
    
    
}
//extension String {
//    var isNumeric: Bool {
//        guard self.count > 0 else { return false }
//        let nums: Set<Character> = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
//        return Set(self.characters).isSubset(of: nums)
//    }
//}
extension UINavigationBar {
    
    func setBottomBorderColor(color: UIColor, height: CGFloat) {
        let bottomBorderRect = CGRect(x: 0, y: frame.height, width: UIScreen.main.bounds.width, height: height)
        let bottomBorderView = UIView(frame: bottomBorderRect)
        bottomBorderView.backgroundColor = color
        addSubview(bottomBorderView)
    }
}


extension UIButton {
    
    private struct AssociatedKeys {
        static var targetClosure = "targetClosure"
    }
    
    private var targetClosure: UIButtonTargetClosure? {
        get {
            guard let closureWrapper = objc_getAssociatedObject(self, &AssociatedKeys.targetClosure) as? ClosureWrapper else { return nil }
            return closureWrapper.closure
        }
        set(newValue) {
            guard let newValue = newValue else { return }
            objc_setAssociatedObject(self, &AssociatedKeys.targetClosure, ClosureWrapper(newValue), objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    func addTargetClosure(closure: @escaping UIButtonTargetClosure) {
        targetClosure = closure
        addTarget(self, action: #selector(UIButton.closureAction), for: .touchUpInside)
    }
    
    @objc func closureAction() {
        guard let targetClosure = targetClosure else { return }
        targetClosure(self)
    }
}

extension UIImage {
    convenience init(view: UIView) {
            UIGraphicsBeginImageContext(view.frame.size)
            view.layer.render(in:UIGraphicsGetCurrentContext()!)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            self.init(cgImage: image!.cgImage!)
    }
    
    func resized(withPercentage percentage: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: size.width * percentage, height: size.height * percentage)
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
    func resized(toWidth width: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: width, height: CGFloat(ceil(width/size.width * size.height)))
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
    func downloadedFrom(url: URL, index: Int, completionHandler: @escaping(_ result : UIImage , _ index : Int) -> Void){
        URLCache.shared.removeAllCachedResponses()
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { () -> Void in
                completionHandler(image , index)
            }
            }.resume()
    }
    
    func downloadedFrom(urlRequest: inout URLRequest, index: Int, completionHandler: @escaping(_ result : UIImage , _ index : Int) -> Void){
        URLCache.shared.removeAllCachedResponses()
        urlRequest.addValue(UserDefaults.standard.value(forKey: "token") as! String, forHTTPHeaderField: "x-access-token")
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { () -> Void in
                completionHandler(image , index)
            }
        }.resume()
    }
}

extension UIApplication {
    class func topViewController(controller: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        return controller
    }
}

extension UnixTime {
    
    private func formatType(form: String) -> DateFormatter
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = form
        return dateFormatter
    }
    
    var datebefore1970:Date{
        
        return Date(timeIntervalSinceNow: Double(self))

    }
    
    var dateFull: Date
    {
        return Date(timeIntervalSince1970: Double(self))
    }
    
    var dateFullLocal: Date
    {
        return Date(timeIntervalSince1970: Double(self)).addingTimeInterval(-Constants().offsetTime)
    }
    
    var toHour: String
    {
        return formatType(form: "HH:mm").string(from: dateFull)
    }
    //1992-06-25

    var AmigoDOB: String
    {
        
        return formatType(form: "yyyy-MM-dd").string(from: dateFull)

    }

    var toDay: String
    {
        return formatType(form: "dd/MM/yyyy").string(from: dateFull)
    }
    
    var toDayFormatprescription: String
    {
        return formatType(form: "dd/MM/yyyy").string(from: dateFull)
    }
    
    //MARK: To get Total Time with Sections
    var totalDayWithTime: String
    {
        return formatType(form: "dd/MM/yyyy'T'HH:mm:ss").string(from: dateFull)

    }
    var dateiwthAMPMtime:String
    {
        
        let dateLocal = dateFull.addingTimeInterval(-Constants().offsetTime)
        
        return formatType(form: "dd/MM/yy hh:mm a").string(from: dateLocal)
        
    }
    var toTime:String
    {
        let dateLocal = dateFull.addingTimeInterval(-Constants().offsetTime)
        
        return formatType(form: "hh:mm a").string(from: dateLocal)
    }
    
    var DatewithfullMonth:String
    {
        return formatType(form: "dd MMMM, yyyy").string(from: dateFull)
    }
    var depeanDEMRdate:String
    {
        return formatType(form: "dd-MM-yyyy").string(from: dateFull)

    }
    var EMRdateNmonth:String
    {
        return formatType(form: "dd-MMM").string(from: dateFull)

    }
    var ConfirmTestDate:String
    {
        return formatType(form: "dd, MMMM yyyy").string(from: dateFull)

    }
    //Convert Date into Milliseconds
}


extension String  {
    var isNumber : Bool {
        get{
            return !self.isEmpty && self.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
        }
    }
}

extension String {
    var first: String {
        return String(characters.prefix(1))
    }
    var last: String {
        return String(characters.suffix(1))
    }
    var uppercaseFirst: String {
        return first.uppercased() + String(characters.dropFirst())
    }
    func chopPrefix(_ count: Int = 1) -> String {
        return substring(from: index(startIndex, offsetBy: count))
    }
    
    func chopSuffix(_ count: Int = 1) -> String {
        return substring(to: index(endIndex, offsetBy: -count))
    }
}

extension UISegmentedControl {
    func removeBorders() {
        setBackgroundImage(imageWithColor(color: backgroundColor!), for: .normal, barMetrics: .default)
        setBackgroundImage(imageWithColor(color: tintColor!), for: .selected, barMetrics: .default)
        setDividerImage(imageWithColor(color: UIColor.clear), forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
    }
    
    // create a 1x1 image with this color
    private func imageWithColor(color: UIColor) -> UIImage {
        let rect = CGRect(x: 0.0, y: 0.0, width:  1.0, height: 1.0)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(color.cgColor);
        context!.fill(rect);
        let image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return image!
    }
}
extension Date {
    
    var yesterday: Date {
        
        return Calendar.current.date(byAdding: .day, value: -1, to: noon)!
    }
    var todayBegin: Date {
        
        return Calendar.current.date(byAdding: .day, value: 0, to: begin)!
    }
    var todayEnd: Date {
        
        return Calendar.current.date(byAdding: .day, value: 0, to: end)!
    }
    var tomorrow: Date {
        
        return Calendar.current.date(byAdding: .day, value: 1, to: noon)!
    }
    var noon: Date {
        
        return Calendar.current.date(bySettingHour: 12, minute: 0, second: 0, of: self)!
    }
    var begin: Date {
        
        return Calendar.current.date(bySettingHour: 0, minute: 0, second: 0, of: self)!
    }
    var end: Date {
        return Calendar.current.date(bySettingHour: 23, minute: 59, second: 59, of: self)!
    }
    var month: Int {
        return Calendar.current.component(.month,  from: self)
    }
    var isLastDayOfMonth: Bool {
        return tomorrow.month != month
    }
}

extension UIImageView {
    func dowloadFromServer(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func dowloadFromServer(link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        dowloadFromServer(url: url, contentMode: mode)
    }
}
extension UIView {
    
        func rotate(_ toValue: CGFloat, duration: CFTimeInterval = 0.2) {
            let animation = CABasicAnimation(keyPath: "transform.rotation")
            
            animation.toValue = toValue
            animation.duration = duration
            animation.isRemovedOnCompletion = false
            animation.fillMode = CAMediaTimingFillMode.forwards
            
            self.layer.add(animation, forKey: nil)
        }
        
    // OUTPUT 1
    func dropShadow(scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: -1, height: 1)
        layer.shadowRadius = 1
        
        layer.shadowPath = UIBezierPath(rect: bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
    
    // OUTPUT 2
    func dropShadow(color: UIColor, opacity: Float = 0.5, offSet: CGSize, radius: CGFloat = 1, scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = color.cgColor
        layer.shadowOpacity = opacity
        layer.shadowOffset = offSet
        layer.shadowRadius = radius
        
        layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
}
extension Array {
    
    func randomItem() -> Element? {
        if isEmpty { return nil }
        let index = Int(arc4random_uniform(UInt32(self.count)))
        return self[index]
    }
}
extension Data {
    var format: String {
        let array = [UInt8](self)
        let ext: String
        switch (array[0]) {
        case 0xFF:
            ext = "image/jpg"
        case 0x89:
            ext = "image/png"
        case 0x47:
            ext = "image/gif"
        case 0x49, 0x4D :
            ext = "image/tiff"
        default:
            ext = "unknown"
        }
        return ext
    }
    
    var fileExt: String {
        let array = [UInt8](self)
        let ext: String
        switch (array[0]) {
        case 0xFF:
            ext = ".jpg"
        case 0x89:
            ext = ".png"
        case 0x47:
            ext = ".gif"
        case 0x49, 0x4D :
            ext = ".tiff"
        default:
            ext = ""
        }
        return ext
    }
}

