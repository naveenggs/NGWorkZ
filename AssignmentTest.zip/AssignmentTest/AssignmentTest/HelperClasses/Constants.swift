//
//  Constants.swift
//  ClientApp
//
//  Created by Naveen Gundu on 21/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import Foundation
import UIKit
import CoreGraphics

typealias Long = Int64

class Constants {
    
    //MARK: Color Constants
    let BaseURL = "http://13.233.218.85/"
    
    
    let AppNGreenColor = "#00ba8c"
    let AppNBlueColor = "#019be3"
    let AppNFBBlueColor = "#3b5998"
    let AppNBoxStrokeColor = "#01a3cb"
    let AppNEyeColor = "#ccccccff"
    let AppNQRStrokeColor = "#235871"
    let AppNBottomBarColor = "#235871"
    let AppNBottomBarStrokeColor = "#235871"
    let AppNIconNLineColor = "#b3b3b3"
    let AppNTextColor = "#808080ff"
    let AppNLGreenColor = "#01B98F"
    
    
    let blueyPurple = UIColor.init(red: 103/255.0, green: 58/255.0, blue: 183/255.0, alpha: 1.0)
    let warmGrey = UIColor.init(red: 158/255.0, green: 158/255.0, blue: 158/255.0, alpha: 1.0)
    
    let blackTwo = UIColor.init(red: 33/255.0, green: 33/255.0, blue: 33/255.0, alpha: 1.0)

    let white = UIColor.init(red: 249/255.0, green: 249/255.0, blue: 249/255.0, alpha: 1.0)
    
    let tomato = UIColor.init(red: 244/255.0, green: 67/255.0, blue: 54/255.0, alpha: 1.0)

    let warmgrey80 = UIColor.init(red: 158/255.0, green: 158/255.0, blue: 158/255.0, alpha: 0.8)
    //rgb 206 206 206
    let pinkishGrey = UIColor.init(red: 206/255.0, green: 206/255.0, blue: 206/255.0, alpha: 0.8)
    
    let BasicBlueLoginColor = "#77B4C6"
    let GreyishBrownColor = "#545454"
    
    let SwitchGreyColor = "#9A9A9A"
    let LightWhiteColor = "#F2F2F2"
    let LightBlueColor = "#4598D2"
    let AppBlueColor = "#069bd7"
    let OLDApplBlueColor = "#189CFA"
    let CustomGreyColor = "#949494"
    
    let UnKnownAppleBlueColor = "#179CD5"
    let UnKnownTwoAppleBlueColor = "#168fcd"
    
    let BasicWhiteColorString = "#FFFFFF"
    let newHomeBGColorString = "#6793ba"
    
    let primaryColorString = "#FDCA5B"
    let primaryLightColor = "#fcedce"
    let primaryDarkColorString = "#ffbb42"
    let secondaryColorString = "#2A577F"
    let light_navy_blue = "#2a577f"
    let primaryStatusBarColorString = "#fbb12d"
    let cloudy_blue = "#c7cadb"
    let bluey_grey_two = "#9397ad"
    let bluey_grey_five = "#7EAACF"
    let bluey_grey = "#A4A8BB"
    let orangeColor = "#f8a224"
    let orangey_red = "#fa4b25"
    let pale_peach = "#ffe2a1"
    let yellowish_orange = "#ffaa12"
    let grass = "#56b732"
    let mango = "#fab12e"
    let slate_grey = "#535664"
    let slate_grey_two = "#646878"
    let slate_grey_70 = "b2535664"
    let pale_grey_two = "#9397ad"
    let pale_grey_three = "#f3f4f8"
    let pale_grey_four = "#e3e4ed"
    let errorColor = "#fb7157"
    let successColor = "#8ad66f"
    let dark_grey = "#1d1e20"
    let backgroundGray = "#efeff4"
    let backgroundDarkGray = "#e0e0e2"
    let charcoal_grey_two = "#444650"
    let highlightText = "#b2ffedc3"
    let light_gold = "#fdca5b"
    let close_color = "#fb4b25"
    let open_color = "#60d86b"
    let navBar = "#ffffff"
    let pale_grey_70 = "#b2e3e4ed"
    let watermelon = "#ff415e"
    let emergenceView = "#ff4141"
    let cartBG = "#33fdca5b"
    let pale_grey_six = "#f2f3f7"
    let turtle_green = "#74c557"
    let fresh_green_three = "#7fd760"
    let fresh_green = "#7FD860"
    let bgGrey = "#99c7cadb"
    
    
    
    //MARK: Font Constants
  
    let FuturaMedium = "Futura-Medium"
    let FuturaBold = "Futura-Bold"
    let FuturaLight = "FuturaBT-Light"

    let FuturaCondensedMedium = "Futura-CondensedMedium"
    let FuturaMediumItalic = "Futura-MediumItalic"
    let FuturaCondensedExtraBold = "Futura-CondensedExtraBold"
 
    let defaultAvenierRegular = "AvenirNext-Regular"
    let defaultAvenierBold = "AvenirNext-Bold"
    let defaultAvenierSemiBold = "AvenirNext-DemiBold"
    let defaultAvenierMedium = "AvenirNext-Medium"
    let defaultAvenierItalic = "AvenirNext-Italic"
    
    
    let offsetTime = TimeInterval(NSTimeZone.local.secondsFromGMT())
    
    
    var fontSize8 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 10 : 8
    var fontSize9 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 11 : 9
    var fontSize10 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 12 : 10
    var fontSize11 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 13 : 11
    var fontSize12 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 14 : 12
    var fontSize13 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 15 : 13
    var fontSize14 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 16 : 14
    var fontSize15 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 17 : 15
    var fontSize16 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 18 : 16
    var fontSize17 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 19 : 17
    var fontSize18 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 20 : 18
    var fontSize19 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 21 : 19
    var fontSize20 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 22 : 20
    var fontSize21 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 23 : 21
    var fontSize22 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 24 : 22
    var fontSize23 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 25 : 23
    var fontSize24 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 26 : 24
    var fontSize26 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 28 : 26
    var fontSize28 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 30 : 28
    var fontSize40 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 38 : 40
    var fontSize50 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 48 : 50
    var fontSize60 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 58 : 60

    var fontSize94 : CGFloat = UIScreen.main.bounds.height > 667.0 ? 94 : 92

    
    var fullWidth:CGFloat = UIScreen.main.bounds.size.width
    var fullheight:CGFloat = UIScreen.main.bounds.size.height
    
    //MARK: Error Msg Constants
    
    let reachabilityerrorString:String = "There is no active internet connection.\n Please reconnect and try again"
    
    let servertimeouterrorString:String = "Response TimedOut"
    
    func setStatusBar(_ color:UIColor){
        
        guard let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView else { return }
        statusBar.backgroundColor = color
        statusBar.backgroundColor?.withAlphaComponent(1.0)
    }

    func iPhone5FamilAvail() -> Bool {
        var avail = Bool()
        
        if UIScreen.main.bounds.size.height == 568 {
            
            avail = true
        }else{
            avail = false
        }
        
        return avail
    }
    
    func iPhoneX() -> Bool {
        var avail = Bool()

        if UIScreen.main.bounds.size.height == 812 {
            avail = true
        }else{
            avail = false
        }
        return avail
    }
    func iPhoneXnAbove() -> Bool {
        
        var final = Bool()
        
        if UIScreen.main.bounds.height >= 812 {
            
            final = true
        }
        return final
    }
    func isWifiAvail() -> Bool {
        
        let networkStatus = Reachability().connectionStatus()
        switch networkStatus {
        case .Unknown, .Offline:
            return false
        case .Online(.WWAN):
            print("Connected via WWAN")
            return false
        case .Online(.WiFi):
            print("Connected via WiFi")
            return true
        }
    }
}
