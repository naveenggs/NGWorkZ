//
//  DCollectionViewCell.swift
//  AssignmentTest
//
//  Created by Naveen Gundu on 25/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import UIKit

class DCollectionViewCell: UICollectionViewCell {
    
    var lblTitle = UILabel()
    
}
