//
//  DataTableViewCell.swift
//  AssignmentTest
//
//  Created by Naveen Gundu on 24/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import UIKit

class DataTableViewCell: UITableViewCell {

    var bgmViewExp = UIControl()
    var tfTeam = SkyFloatingLabelTextField()
    var tfBat = SkyFloatingLabelTextField()
    var tfBowl = SkyFloatingLabelTextField()
    var tfAge = SkyFloatingLabelTextField()
    var tfPriice = SkyFloatingLabelTextField()

    var bgmViewnoExp = UIControl()
    var iconS = UIImageView()
    var profilePic = UIImageView()
    var lblUsername = UILabel()
    var lblUserCategory = UILabel()
    var lblUserBuilding = UILabel()

    var lblPointsTitle = UILabel()
    var lblPointsData = UILabel()

    var bottomlIne = UILabel()
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
                
    }
    func setCollapsed(_ collapsed: Bool) {
        //
        // Animate the arrow rotation (see Extensions.swf)
        //
//        arrowLabel.rotate(collapsed ? 0.0 : .pi / 2)
        iconS.rotate(collapsed ? 0.0 : .pi / 2)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
