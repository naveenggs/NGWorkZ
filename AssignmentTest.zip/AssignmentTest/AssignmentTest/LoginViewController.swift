//
//  LoginViewController.swift
//  AssignmentTest
//
//  Created by Naveen Gundu on 24/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    //MARK: Variables
    
    var strEmail = String()
    var strPassword = String()
    var dictJsonData = [String:Any]()
    var strToken = String()

    let nWidth = UIScreen.main.bounds.width
    let nHeight = UIScreen.main.bounds.height
    
    //MARK: Outlets
    
    @IBOutlet weak var tfEmail: SkyFloatingLabelTextField!
    
    @IBOutlet weak var tfPassword: SkyFloatingLabelTextField!
    
    @IBOutlet weak var btnLogin: UIButton!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        self.navigationController?.navigationBar.isHidden = false

    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        DispatchQueue.main.async {
            
            self.setInitilaView()
        }
    }
    
    //maheshwari@techcetra.com, qwerty123

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func loginAct(_ sender: UIButton) {
        
        self.strEmail = self.tfEmail.text!
        self.strPassword = self.tfPassword.text!
        
        if strEmail != "" && strPassword != "" {
            
            if strEmail == "maheshwari@techcetra.com" && strPassword == "qwerty123"{
                
                self.LogiWebcall { (result, errorString) in
                    
                    if result{
                        
                        OperationQueue.main.addOperation {
                            
                            let stBoard = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainDataViewController") as! MainDataViewController
                            stBoard.userAuthData = self.dictJsonData
                            GenericHelper().customPush(self, viewControler: stBoard, animation: true)
                            
                        }
//                        DispatchQueue.main.async {
//
//                            let stBoard = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainDataViewController") as! MainDataViewController
//                            stBoard.userAuthData = self.dictJsonData
//                            GenericHelper().customPush(self, viewControler: stBoard, animation: true)
//                        }
                    }else{
                        
                        self.showCustomAlert("", "JSON Loadimg data error!")

                    }
                }
                
            }else{
                
                self.showCustomAlert("", "Please enter valid Data!")
            }
            
        }else{
            
            self.showCustomAlert("", "Please enter Data!")

        }
        
    }
    
    func setInitilaView() {
        
        self.tfEmail.frame = CGRect(x: 30, y: nHeight / 2 - 110, width: nWidth - 60, height: 40)
        self.tfPassword.frame = CGRect(x: 30, y: nHeight / 2 - 60, width: nWidth - 60, height: 40)
        self.btnLogin.frame = CGRect(x: nWidth / 2 - 55, y: nHeight / 2, width: 110, height: 34)
        btnLogin.setTitleColor(.white, for: .normal)
        btnLogin.setTitle("Log In", for: .normal)
        btnLogin.backgroundColor = UIColor.init(hexString: "#00ABB5")
        btnLogin.titleLabel?.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize16)
        btnLogin.tag = 21
        btnLogin.layer.cornerRadius = 15.0
        btnLogin.layer.masksToBounds = true
    }

}
extension LoginViewController{
    
    func LogiWebcall(completion: @escaping (_ success: Bool , _ errorString : String) -> ())
    {
        var result : Bool = true
        var errorString : String = ""
        
        var request : URLRequest
        
        let requestURL = URL(string:"\(Constants().BaseURL + "api/user/login")")!

        print(requestURL)
        request = URLRequest(url: requestURL)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
//        request.addValue(mainToken, forHTTPHeaderField: "x-access-token")
        request.httpMethod = "POST"
        
        var paramPostDict = [String:Any]()
        
        paramPostDict["email"] = self.strEmail
        paramPostDict["password"] = self.strPassword
        

        if ConnectivityHelper().isInternetAvailable() {
            
            var task =  sendRequest(urlRequest: request, parameters: paramPostDict as [String : AnyObject] ) { (data, response, error) in
                // dismiss hud
                
                
                if error != nil {
                    
                    result = false
                    errorString = Constants().servertimeouterrorString
                    
                }
                else
                {
                    do
                    {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                        {
                            
                            //Implement your logic
                            print("JSON Data", json)
                            self.dictJsonData = json
                            result = self.dictJsonData["success"] as! Bool
                            
                        }
                        
                    }
                    catch
                    {
                        print("error in JSONSerialization")
                        result = false
                        errorString = "Json Parse Error"
                        
                    }
                    
                }
                
                completion(result, errorString)
            }
            
            
        }
        else
        {
            let alertController = UIAlertController(title: Constants().reachabilityerrorString as String, message:nil, preferredStyle: UIAlertController.Style.alert)
            
            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
                
            }
            
            alertController.addAction(okAction)
            
            self.present(alertController, animated: true, completion: nil)
            
            
        }
    }
    
    func showCustomAlert(_ message:String, _ Title:String) {
        
        let alertController = UIAlertController(title: Title, message:nil, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
            
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
}
//MARK: TextField Delegate
extension LoginViewController:UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }
}
