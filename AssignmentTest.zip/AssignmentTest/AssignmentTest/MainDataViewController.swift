//
//  MainDataViewController.swift
//  AssignmentTest
//
//  Created by Naveen Gundu on 24/01/19.
//  Copyright © 2019 NG. All rights reserved.
//

import UIKit

class MainDataViewController: UIViewController {

    @IBOutlet weak var tableViewData: UITableView!
    
    var userAuthData = [String:Any]()
    
    var mainToken = String()
    
    var allUserData = [Any]()
    
    var filteres = [String:Any]()
    var filternames = [String]()
    var colorArray = [Any]()

    var selectedCategory = String()
    var selectedDataArray = [Any]()
    
    var filteredData = [Any]()
    
    var buttonsData = [UIButton]()
    
    let nWidth = UIScreen.main.bounds.width
    let nHeight = UIScreen.main.bounds.height
    
    private var dateCellExpanded: Bool = false
    
    @IBOutlet weak var collectionviewFilter: UICollectionView!
    var selectedIndex = Int()
    
    @IBOutlet weak var btnFilter: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        collectionviewFilter.isHidden = true
        
        self.navigationController?.navigationBar.isHidden = true
        if let dataDict = userAuthData["data"]{
            var data = [String:Any]()
            data = dataDict as! [String:Any]
            self.mainToken = data["token"] as! String
        }
        DispatchQueue.main.async {
            
            self.setInitialView()
        }
        
        self.getAllFilteres { (result, errorString) in
            
            if result{
                
            }else{
                
                self.showCustomAlert("", errorString)
            }
        }
        
        self.getAllPlayerData { (result, errorString) in
            
            if result{
                
                DispatchQueue.main.async {
                    
                    GenericHelper().dismissShow(view: self.view)

                    self.tableViewData.reloadData()
                }
                
            }else{
                
                self.showCustomAlert("", errorString)
            }
        }
        
    }
    
    func setInitialView() {
        
        var yforna = CGFloat()
        var btnY = CGFloat()
        
        if Constants().iPhoneXnAbove() {
            
            yforna = 40
            btnY = 110
            
        }else{
            btnY = 70
            yforna = 20
        }
        self.tableViewData.frame = CGRect(x: 8, y: yforna, width: nWidth - 16, height: nHeight - yforna - 40)
        self.tableViewData.register(DataTableViewCell.self, forCellReuseIdentifier: "DataTableViewCell")
        tableViewData.tableFooterView = UIView()

        self.btnFilter.frame = CGRect(x: nWidth - 58, y: nHeight - btnY, width: 48, height: 48)
        self.btnFilter.layer.cornerRadius = self.btnFilter.frame.size.height / 2
        self.btnFilter.layer.masksToBounds = true
        self.btnFilter.addTargetClosure { _ in
            
            DispatchQueue.main.async {
                
                self.showFilterPopUp()
            }
        }
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        self.navigationController?.navigationBar.isHidden = false
        
    }
    func removeSpecialCharsFromString(_ str: String) -> String {
        struct Constants {
            static let validChars = Set("1234567890-".characters)
        }
        return String(str.characters.filter { Constants.validChars.contains($0) })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func showFilterPopUp() {
        
        var heigh = CGFloat()
        
        if Constants().iPhoneXnAbove() {
            
            heigh = 260
        }else{
            heigh = 210
        }
        if let pView = self.view.viewWithTag(99) {
            pView.removeFromSuperview()
        }
        
        let viewtoshowViewPopUp = UIView()
                viewtoshowViewPopUp.tag = 99
                viewtoshowViewPopUp.backgroundColor = UIColor.init(fromHexString: Constants().slate_grey, 0.5)
                viewtoshowViewPopUp.frame = CGRect(x:0, y:0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        
        let vpHeight = viewtoshowViewPopUp.frame.size.height
        let vpWidth = viewtoshowViewPopUp.frame.size.width
        
        let bottomPopUpView = UIView.init(frame: CGRect(x: 0, y: vpHeight - heigh, width: vpWidth, height: heigh))
        bottomPopUpView.backgroundColor = UIColor.init(hexString: Constants().AppBlueColor)
        
        let scV = self.showFilterBar(filternames.count, filternames, mView: bottomPopUpView, colorArray)
        bottomPopUpView.addSubview(scV)
    
        self.selectedDataArray = self.getArraydatFromDict(filternames[0], self.filteres)

//        let layout = UICollectionViewFlowLayout()
//
//        layout.itemSize = CGSize(width: 80, height: 50)
//
//        let collectionViewfriends = UICollectionView(frame: CGRect(x:4,y:61,width:vpWidth - 8,height:139), collectionViewLayout: layout)
//
        if collectionviewFilter.isHidden == true{
            collectionviewFilter.isHidden = false
        }
        collectionviewFilter.frame = CGRect(x: 4, y: 75, width: vpWidth - 8, height: 140)
        collectionviewFilter.delegate = self
        collectionviewFilter.dataSource = self
        collectionviewFilter.tag = 101
        collectionviewFilter.register(DCollectionViewCell.self, forCellWithReuseIdentifier: "DCollectionViewCell")
        collectionviewFilter.backgroundColor = .clear
        collectionviewFilter.isScrollEnabled = true
        collectionviewFilter.showsHorizontalScrollIndicator = false
        collectionviewFilter.showsVerticalScrollIndicator = false
        
        collectionviewFilter.reloadData()
//        layout.scrollDirection = .horizontal
//        collectionViewfriends.reloadData()
//bottomPopUpView
        
//        bottomPopUpView.frame.size.height = collectionviewFilter.contentSize.height
        
        let noBtn = UIButton.init(frame: CGRect(x: bottomPopUpView.frame.size.width / 2 - 80, y: bottomPopUpView.frame.size.height - 80, width: 40, height: 40))
        noBtn.setImage(UIImage.init(named: "No.png"), for: .normal)
        noBtn.addTargetClosure { _ in
            if let pView = self.view.viewWithTag(99) {
                pView.removeFromSuperview()
            }
        }
        let yesBtn = UIButton.init(frame: CGRect(x: bottomPopUpView.frame.size.width / 2 + 80, y: noBtn.frame.origin.y, width: 40, height: 40))
        yesBtn.setImage(UIImage.init(named: "OK.png"), for: .normal)
        yesBtn.addTargetClosure { _ in
            if let pView = self.view.viewWithTag(99) {
                pView.removeFromSuperview()
            }
            self.getAllPlayerFilteredData(completion: { (result, errorString) in
            
                if result{
                    
                    DispatchQueue.main.async {
                        GenericHelper().dismissShow(view: self.view)
                        self.tableViewData.reloadData()
                    }
                    
                }else{
                    
                    self.showCustomAlert("", errorString)
                }
            })
        }
        bottomPopUpView.addSubview(collectionviewFilter)

        bottomPopUpView.addSubview(yesBtn)
        bottomPopUpView.addSubview(noBtn)
        
        bottomPopUpView.backgroundColor = UIColor.white
        viewtoshowViewPopUp.addSubview(bottomPopUpView)
        view.addSubview(viewtoshowViewPopUp)
        
    }
    
    func showFilterBar(_ btnCount:Int, _ data:[Any], mView:UIView, _ downColor:[Any]) -> UIScrollView {
        
        if let Scv = self.view.viewWithTag(12) {
            Scv.removeFromSuperview()
        }
        
        var finalScrollView = UIScrollView()
        
        finalScrollView.frame = CGRect(x:0, y:1, width:mView.frame.size.width, height:60)
        
        finalScrollView.tag = 12
        
        finalScrollView.delegate = self
        
        let widthForElements = finalScrollView.frame.size.width / 4 - 8
        
        var xforElemets = CGFloat()
        
        xforElemets = 8.0
        
        for n in 0..<data.count {
            
            let btn = UIButton.init(frame: CGRect(x:xforElemets,y:12,width:70,height:45))
//            btn.setTitleColor(titlesColor[n] as? UIColor, for: .normal)
            btn.titleLabel?.font = UIFont.init(name: Constants().defaultAvenierMedium, size: Constants().fontSize15)
            btn.setTitleColor(UIColor.white, for: .normal)
            btn.layer.cornerRadius = 4.0
            btn.layer.masksToBounds = true
            let name = data[n] as? String
//            let newStr : String = self.removeSpecialCharsFromString(name)
            btn.setTitle(name?.capitalized, for: .normal)
            btn.sizeToFit()
            btn.tag = n
            btn.frame.origin = CGPoint(x: xforElemets, y: 12)
            //            btn.backgroundColor = .red
            let downLbl = UILabel.init(frame: CGRect(x:btn.frame.origin.x,y:43,width:btn.frame.size.width,height:1))
            downLbl.backgroundColor = downColor[n] as? UIColor
            downLbl.layer.cornerRadius = downLbl.frame.size.height / 2
            downLbl.layer.masksToBounds = true
            xforElemets += btn.frame.size.width + 8.0
            finalScrollView.addSubview(btn)
            btn.addTarget(self, action: #selector(self.selectBtnAct(_:)), for: .touchUpInside)
            finalScrollView.addSubview(downLbl)
        }
        
        finalScrollView.contentSize.width = xforElemets + 10.0
        finalScrollView.isScrollEnabled = true
        finalScrollView.showsHorizontalScrollIndicator = true
        finalScrollView.backgroundColor = UIColor.blue
        
        return finalScrollView
    }

    func getArraydatFromDict(_ key:String, _ dict:[String:Any]) -> [Any] {
        
        var fArray = [Any]()
        
        fArray = dict[key] as! [Any]
        
        return fArray
    }
    @objc func selectBtnAct(_ sender:UIButton) {
        
        let selectedIndex = sender.tag
        
        if let nView = self.view.viewWithTag(12) {
            
            nView.removeFromSuperview()
        }
        
        self.selectedCategory = self.filternames[selectedIndex]
        
        self.selectedDataArray = self.getArraydatFromDict(selectedCategory, self.filteres)
        
        self.collectionviewFilter.reloadData()
        
//        self.titlesColor = [UIColor.init(hexString: "#9E9E9E"), UIColor.init(hexString: "#9E9E9E"), UIColor.init(hexString: "#9E9E9E"), UIColor.init(hexString: "#9E9E9E")]
//
//        self.dotColorArray = [UIColor.clear, UIColor.clear, UIColor.clear, UIColor.clear]
//
//        self.selectedType = self.dataArray[selectedIndex] as! String
//
//        self.titlesColor.remove(at: selectedIndex)
//
//        self.dotColorArray.remove(at: selectedIndex)
//
//        self.titlesColor.insert(UIColor.init(hexString: Constants().AppBGMColor), at: selectedIndex)
//
//        self.dotColorArray.insert(UIColor.init(hexString: Constants().AppBGMColor), at: selectedIndex)
//
//        self.segmentSCview.frame = CGRect(x: 0, y: yforSC, width: view.frame.size.width, height: 50)
//
//        self.segmentSCview = self.setCustomScrollLayout(data: dataArray, colors: colorArray, titlesColor: self.titlesColor, mView: view)
//
//        self.segmentSCview.setContentOffset(scPoint, animated: true)
//
//        self.addCateScrollView.addSubview(segmentSCview)
//
//        view.addSubview(addCateScrollView)
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension MainDataViewController{
    
    func showCustomAlert(_ message:String, _ Title:String) {
        
        let alertController = UIAlertController(title: Title, message:nil, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
            
        }
        
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    ///api/players/filters
    
    func getAllPlayerData(completion: @escaping (_ success: Bool , _ errorString : String) -> ())
    {
        var result : Bool = true
        var invalideToken : Bool = false
        var errorString : String = ""
        var request : URLRequest
        
        
        let requestURL = URL(string:"\(Constants().BaseURL + "api/players")")!
        
        print(requestURL)
        request = URLRequest(url: requestURL)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(mainToken, forHTTPHeaderField: "token")
        request.httpMethod = "POST"
        
        let paramPostDict = [:] as [String : AnyObject]
        
        GenericHelper().hudShow(view: view, string: "Loading...")
        // Check Internet Reachability and show hud
        
        if ConnectivityHelper().isInternetAvailable() {
            
            
            var task =  sendRequest(urlRequest: request, parameters: paramPostDict ) { (data, response, error) in
                // dismiss hud
                
                
                if error != nil {
                    
                    result = false
                    errorString = Constants().servertimeouterrorString
                    
                }
                else
                {
                    
                    do
                    {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                        {
                            
                            //Implement your logics
                            
                            result = json["success"] as! Bool
                            self.allUserData.removeAll()
                            if let dataDict = json["data"]{
                                var data = [String:Any]()
                                data = dataDict as! [String:Any]
                                self.allUserData = data["players"] as! [Any]
                            }
                            
                            print("JSON DATA", json)
                            
                        }
                        
                    }
                    catch
                    {
                        
                        print("error in JSONSerialization")
                        //send custom error string
                        result = false
                        invalideToken = false
                        errorString = "Json Parse Error"
                        
                    }
                    
                    
                }
                
                completion(result, errorString)
            }
            
            
        }
        else
        {
                self.showCustomAlert("", Constants().reachabilityerrorString)
                
        }
    }
    
    func getAllPlayerFilteredData(completion: @escaping (_ success: Bool , _ errorString : String) -> ())
    {
        var result : Bool = true
        var invalideToken : Bool = false
        var errorString : String = ""
        var request : URLRequest
        
        let requestURL = URL(string:"\(Constants().BaseURL + "api/players")")!
        
        print(requestURL)
        request = URLRequest(url: requestURL)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue(mainToken, forHTTPHeaderField: "token")
        request.httpMethod = "POST"
        //skills 1, 2, team_status 1,0, categories 1 buildings  4
        
        var paramPostDict = [String : Any]()
        paramPostDict["category"] = [1]
        paramPostDict["team_status"] = [1]
        paramPostDict["skills"] = [1, 2]
        paramPostDict["buildings"] = [4]
//        category (comma separated category ids) (O)
//        skill (comma separated skill ids) (O)
//        building (comma separated building ids) (O)
//        team_status (integer) (O)
        // Check Internet Reachability and show hud
        GenericHelper().hudShow(view: view, string: "Loading...")

        if ConnectivityHelper().isInternetAvailable() {
            
            
            var task =  sendRequest(urlRequest: request, parameters: paramPostDict as [String : AnyObject] ) { (data, response, error) in
                // dismiss hud
                
                
                if error != nil {
                    
                    result = false
                    errorString = Constants().servertimeouterrorString
                    
                }
                else
                {
                    
                    do
                    {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                        {
                            
                            //Implement your logics
                            
                            result = json["success"] as! Bool
                            
                            self.allUserData.removeAll()
                            
                            if let dataDict = json["data"]{
                                var data = [String:Any]()
                                data = dataDict as! [String:Any]
                                self.allUserData = data["players"] as! [Any]
                            }
                            
                            print("JSON User Filters DATA", json)
                            
                        }
                        
                    }
                    catch
                    {
                        
                        print("error in JSONSerialization")
                        //send custom error string
                        result = false
                        invalideToken = false
                        errorString = "Json Parse Error"
                        
                    }
                    
                    
                }
                
                completion(result, errorString)
            }
            
            
        }
        else
        {
          self.showCustomAlert("", Constants().reachabilityerrorString)
        
        }
    }
    
    //MARk: FILTERS
    func getAllFilteres(completion: @escaping (_ success: Bool , _ errorString : String) -> ())
    {
        var result : Bool = true
        var invalideToken : Bool = false
        var errorString : String = ""
        var request : URLRequest
        //http://13.233.218.85/api/players/filters
        let requestURL = URL(string:"\(Constants().BaseURL + "api/players/filters")")!
        
        print(requestURL)
        request = URLRequest(url: requestURL)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.addValue(mainToken, forHTTPHeaderField: "token")
        request.httpMethod = "GET"
        
        let paramPostDict = [:] as [String : AnyObject]
        
        // Check Internet Reachability and show hud
        
        if ConnectivityHelper().isInternetAvailable() {
            
            
            var task =  sendRequest(urlRequest: request, parameters: paramPostDict ) { (data, response, error) in
                // dismiss hud
                
                
                if error != nil {
                    
                    result = false
                    errorString = Constants().servertimeouterrorString
                    
                }
                else
                {
                    
                    do
                    {
                        if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]
                        {
                            
                            //Implement your logics
                            
                            result = json["success"] as! Bool
                            
                            if let dataDict = json["data"]{
                                var data = [String:Any]()
                                data = dataDict as! [String:Any]
                                self.filteres.removeAll()

//                                self.allUs = data["players"] as! [Any]
                                self.filteres = data
                                
                                self.colorArray.removeAll()
                                self.filternames.removeAll()
                                self.filternames = [String](self.filteres.keys)
                                
                                for G in 0..<self.filternames.count{
                                    
                                    if G == 0{
                                        self.colorArray.append(UIColor.white)
                                    }else{
                                        self.colorArray.append(UIColor.clear)
                                    }
                                }
                                
                                print("filternames", self.filternames)
                            }
                            
                            print("JSON Filters DATA", self.filteres)
                            
                        }
                        
                    }
                    catch
                    {
                        
                        print("error in JSONSerialization")
                        //send custom error string
                        result = false
                        errorString = "Json Parse Error"
                        
                    }
                    
                    
                }
                
                completion(result, errorString)
            }
            
            
        }
        else
        {
            self.showCustomAlert("", Constants().reachabilityerrorString)
            
        }
    }
    
}
extension MainDataViewController:UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return self.allUserData.count
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let dCell:DataTableViewCell = tableView.dequeueReusableCell(withIdentifier: "DataTableViewCell", for: indexPath) as! DataTableViewCell
        dCell.contentView.frame = dCell.contentView.frame.inset(by: UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8))
        dCell.contentView.backgroundColor = .white
        let dataDict = self.allUserData[indexPath.section] as! [String:Any]
        let picURL = URL(string:dataDict["picture"] as! String)
        let picURLStr = dataDict["picture"] as? String ?? ""

        let pName = dataDict["name"] as? String ?? "-"
        let pPoint = dataDict["points"] as? Int ?? 0
        let pCategory = dataDict["category_name"] as? String ?? "-"
        let pBuilding = dataDict["building"] as? String ?? "-"
        let pTeam = dataDict["team"] as? String ?? "-"
        let pBat = dataDict["batsman"] as? String ?? "-"
        let pBowl = dataDict["bowler"] as? String ?? "-"
        let pAge = dataDict["age"] as? String ?? "-"
        let pPrice = dataDict["base_price"] as? String ?? "-"
                
        let ccWidth = dCell.contentView.frame.size.width
        let ccHeight = dCell.contentView.frame.size.height
        
        dCell.contentView.layer.borderColor = UIColor.init(hexString: Constants().AppBlueColor)?.cgColor
        dCell.contentView.layer.cornerRadius = 4.0
        dCell.contentView.layer.masksToBounds = true
        dCell.contentView.layer.borderWidth = 1.0
        
        dCell.iconS.frame = CGRect(x: 4, y: 25, width: 20, height: 20)
        dCell.iconS.image = UIImage.init(named: "OpenBlue.png")
        
        dCell.profilePic.frame = CGRect(x: 32, y: 7, width: 58, height: 58)
        dCell.profilePic.layer.cornerRadius = dCell.profilePic.frame.size.height / 2
        dCell.profilePic.layer.masksToBounds = true
        dCell.profilePic.dowloadFromServer(link: picURLStr, contentMode: .scaleAspectFit)
        dCell.lblUsername.frame = CGRect(x: 100, y: 0, width: 150, height: 22)
        dCell.lblUsername.font = UIFont.init(name: Constants().defaultAvenierMedium, size: Constants().fontSize13)
        dCell.lblUsername.text = pName
        
        dCell.lblUserCategory.frame = CGRect(x: 100, y: 22, width: 130, height: 22)
        dCell.lblUserCategory.font = UIFont.init(name: Constants().defaultAvenierMedium, size: Constants().fontSize13)
        dCell.lblUserCategory.text = pCategory
        
        dCell.lblUserBuilding.frame = CGRect(x: 100, y: 44, width: 130, height: 22)
        dCell.lblUserBuilding.font = UIFont.init(name: Constants().defaultAvenierMedium, size: Constants().fontSize13)
        dCell.lblUserBuilding.text = pBuilding
        
        dCell.lblPointsTitle.frame = CGRect(x: ccWidth - 75, y: 8, width: 70, height: 24)
        dCell.lblPointsTitle.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize13)
        dCell.lblPointsTitle.textAlignment = .center
        dCell.lblPointsTitle.text = "POINTS"
        
        dCell.lblPointsData.frame = CGRect(x: ccWidth - 75, y: 32, width: 70, height: 26)
        dCell.lblPointsData.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize14)
        dCell.lblPointsData.textAlignment = .center
        dCell.lblPointsData.text = String(pPoint)
        dCell.lblPointsData.textColor = .green
        
        dCell.bottomlIne.frame = CGRect(x: 8, y: 73, width: ccWidth - 16, height: 1)
        dCell.bottomlIne.backgroundColor = UIColor.init(hexString: Constants().AppBlueColor)
        
        dCell.tfTeam.frame = CGRect(x: 34, y: 81, width: ccWidth - 68, height: 42)
        dCell.tfTeam.placeholder = "TEAM:"
        dCell.tfTeam.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize13)
        dCell.tfTeam.lineColor = UIColor.init(hexString: Constants().AppBlueColor)
        dCell.tfTeam.text = pTeam.uppercased()
        
        dCell.tfBat.frame = CGRect(x: 34, y: 123, width: ccWidth - 68, height: 42)
        dCell.tfBat.placeholder = "BAT:"
        dCell.tfBat.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize13)
        dCell.tfBat.lineColor = UIColor.init(hexString: Constants().AppBlueColor)
        dCell.tfBat.text = pBat.uppercased()
        
        dCell.tfBowl.frame = CGRect(x: 34, y: 169, width: ccWidth - 68, height: 42)
        dCell.tfBowl.placeholder = "BOWL:"
        dCell.tfBowl.lineColor = UIColor.init(hexString: Constants().AppBlueColor)
        dCell.tfBowl.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize13)
        dCell.tfBowl.text = pBowl.uppercased()
        
        dCell.tfAge.frame = CGRect(x: 34, y: 215, width: ccWidth - 68, height: 42)
        dCell.tfAge.placeholder = "AGE:"
        dCell.tfAge.lineColor = UIColor.init(hexString: Constants().AppBlueColor)
        dCell.tfAge.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize13)
        dCell.tfAge.text = pAge.uppercased()
        
        dCell.tfPriice.frame = CGRect(x: 34, y: 261, width: ccWidth - 68, height: 42)
        dCell.tfPriice.placeholder = "PRICE:"
        dCell.tfPriice.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize13)
        dCell.tfPriice.lineColor = UIColor.init(hexString: Constants().AppBlueColor)
        dCell.tfPriice.text = pPrice.uppercased()
        
        dCell.contentView.addSubview(dCell.iconS)
        dCell.contentView.addSubview(dCell.profilePic)
        dCell.contentView.addSubview(dCell.lblUsername)
        dCell.contentView.addSubview(dCell.lblUserCategory)
        dCell.contentView.addSubview(dCell.lblUserBuilding)
        dCell.contentView.addSubview(dCell.lblPointsTitle)
        dCell.contentView.addSubview(dCell.lblPointsData)
        dCell.contentView.addSubview(dCell.bottomlIne)
        dCell.contentView.addSubview(dCell.tfTeam)
        dCell.contentView.addSubview(dCell.tfBat)
        dCell.contentView.addSubview(dCell.tfBowl)
        dCell.contentView.addSubview(dCell.tfAge)
        dCell.contentView.addSubview(dCell.tfPriice)
    
//        GenericHelper().applyLayerShadowDeep(dCell.contentView)

        if indexPath.section == selectedIndex {
            if dateCellExpanded {
                dCell.bgmViewExp.frame.size.height = 296
                dCell.setCollapsed(true)
                 dCell.tfPriice.isHidden = false
                 dCell.tfAge.isHidden = false
                 dCell.tfBowl.isHidden = false
                 dCell.tfBat.isHidden = false
                 dCell.tfTeam.isHidden = false
                 dCell.bottomlIne.isHidden = false
                dCell.contentView.layer.cornerRadius = 4.0
                dCell.contentView.layer.masksToBounds = true

            }else{
                dCell.bgmViewExp.frame.size.height = 60

                dCell.tfPriice.isHidden = true
                dCell.tfAge.isHidden = true
                dCell.tfBowl.isHidden = true
                dCell.tfBat.isHidden = true
                dCell.tfTeam.isHidden = true
                dCell.bottomlIne.isHidden = true
                dCell.contentView.layer.cornerRadius = 4.0
                dCell.contentView.layer.masksToBounds = true
            }
            
        }else{

            dCell.bgmViewExp.frame.size.height = 60

            dCell.tfPriice.isHidden = true
            dCell.tfAge.isHidden = true
            dCell.tfBowl.isHidden = true
            dCell.tfBat.isHidden = true
            dCell.tfTeam.isHidden = true
            dCell.bottomlIne.isHidden = true
            dCell.contentView.layer.cornerRadius = 4.0
            dCell.contentView.layer.masksToBounds = true
        }
        
        return dCell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        if indexPath.row == 0 {
        let selectedINDEX = tableView.indexPathForSelectedRow!
        
        selectedIndex = selectedINDEX.section
        if dateCellExpanded {
            dateCellExpanded = false
        } else {
            dateCellExpanded = true
        }
        tableView.beginUpdates()
        tableView.endUpdates()
        self.tableViewData.reloadData()
        //}
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        var final = CGFloat()
        
        if indexPath.section == selectedIndex {
            
            if dateCellExpanded {
                final = 314
            } else {
                final = 72
            }
        }else{
            final = 72
        }
        return final
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 14.0
    }
    
    // Make the background color show through
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
}
extension MainDataViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return selectedDataArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let dCEll:DCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DCollectionViewCell", for: indexPath) as! DCollectionViewCell
        
        dCEll.lblTitle.frame = CGRect(x: 2, y: 0, width: dCEll.contentView.frame.size.width - 4, height: 40)
        dCEll.lblTitle.layer.cornerRadius = 10.0
        dCEll.lblTitle.layer.masksToBounds = true
        dCEll.lblTitle.clipsToBounds = true
        dCEll.lblTitle.font = UIFont.init(name: Constants().defaultAvenierRegular, size: Constants().fontSize14)
        dCEll.lblTitle.textColor = UIColor.init(hexString: Constants().AppBlueColor)
        dCEll.lblTitle.layer.borderColor = UIColor.init(hexString: Constants().AppBlueColor).cgColor
        dCEll.lblTitle.layer.borderWidth = 1.0
        
        let getData = selectedDataArray[indexPath.item] as! [String:Any]
        let title = getData["name"] as? String ?? ""
        dCEll.lblTitle.text = title
        dCEll.lblTitle.textAlignment = .center
        
        dCEll.contentView.addSubview(dCEll.lblTitle)
        return dCEll
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 150, height: 40)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let selctedItems = collectionView.indexPathsForSelectedItems!
        
        let finalIndex = selctedItems[0]
        
        let slectedData = self.selectedDataArray[finalIndex.item]
        
        print("Did...Selected", slectedData)
        
    }
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.white
    }
}
